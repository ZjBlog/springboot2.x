package com.jd.jdd.yfk.util;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jd.jdd.yfk.util.JsonUtil;

/**
 * 
 * @author liyuliang5
 *
 */
public class JSONTest {

	public static final Logger logger = LoggerFactory.getLogger(JSONTest.class);

	@Test
	public void test2St() {
		logger.info("null:" + JsonUtil.toJSONString(null));
		logger.info("1" + JsonUtil.toJSONString(1));
		logger.info("123:" + JsonUtil.toJSONString("123"));
		logger.info("date:" + JsonUtil.toJSONString(new Date()));
		logger.info("map:" + JsonUtil.toJSONString(new HashMap()));
		logger.info("object:" + JsonUtil.toJSONString(new Object()));

	}
	
	@Test
	public void test2Object() {
		logger.info("null:" + JsonUtil.parseObject("null", Object.class));
		logger.info("1" + JsonUtil.parseObject("1", Integer.class));
		logger.info("123:" + JsonUtil.parseObject("123", String.class));
		logger.info("date:" + JsonUtil.parseObject("1591418665721", Date.class));
		logger.info("map:" + JsonUtil.parseObject("{}", Map.class));
		logger.info("object:" + JsonUtil.parseObject("{}", Object.class));
	}
	
}

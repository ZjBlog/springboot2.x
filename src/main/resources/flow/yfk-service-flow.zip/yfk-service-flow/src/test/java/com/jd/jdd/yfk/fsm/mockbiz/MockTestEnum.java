package com.jd.jdd.yfk.fsm.mockbiz;

/**
 * @author zhangjun486
 * @version 1.0
 * @date 2020/7/14 15:41
 * @Description
 */
public enum  MockTestEnum {

    TT("Test"),
    ;
    MockTestEnum(String desc){
        this.desc=desc;
    }
    private String desc;

    public String getDesc() {
        return desc;
    }
}

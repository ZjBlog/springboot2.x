package com.jd.jdd.yfk.flow.mockbiz.loan.contract;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LoanContractSignBiz {

    public static final Logger logger = LoggerFactory.getLogger(LoanContractSignBiz.class);
    
    public void sign() {
        logger.info("sign");
    }
}

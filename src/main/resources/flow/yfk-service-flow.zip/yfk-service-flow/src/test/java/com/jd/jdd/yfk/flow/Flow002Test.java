package com.jd.jdd.yfk.flow;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jd.jdd.yfk.flow.engine.FlowParam;
import com.jd.jdd.yfk.flow.engine.FlowResult;
import com.jd.jdd.yfk.flow.engine.impl.FlowEngineImpl;

public class Flow002Test {
    
    public static final Logger logger = LoggerFactory.getLogger(Flow002Test.class);

    @Test
    public void testFlow002() {
        FlowEngineImpl flowEngine = new FlowEngineImpl();
        flowEngine.setFlowPath("classpath:flow/flow002.json");
        flowEngine.init();
        
        FlowParam param = new FlowParam();
        param.setFlowId("flow002");
        Map<String, Object> paramData = new HashMap<>();
        paramData.put("amount", new BigDecimal(80));
        param.setParam(paramData);
        
        FlowResult result = flowEngine.execute(param);
        logger.info("执行结果为:" + result);
    }
}

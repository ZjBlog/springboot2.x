/*
* @(#)CheckBiz.java 1.0 2020年6月25日
*
* Copyright (c) 2019 JDD. All rights reserved.
* PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
*/
package com.jd.jdd.yfk.flow.mockbiz.loan;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jd.jdd.yfk.flow.engine.FlowContext;
import com.jd.jdd.yfk.flow.model.NodeContext;

/**
* 
* TODO
* @author liyuliang5
* @version 1.0
* @since 1.0
*/

public class CheckBiz {
    
    private static final Logger logger = LoggerFactory.getLogger(CheckBiz.class);

    public void paramCheck(FlowContext context, NodeContext nodeContext) {
        System.out.println("dddd");
        System.out.println(context.getParam().getParam().toString());
        logger.info("paramCheck");
    }
    
    public void authCheck(FlowContext context) {
        logger.info("authCheck");
    }
}

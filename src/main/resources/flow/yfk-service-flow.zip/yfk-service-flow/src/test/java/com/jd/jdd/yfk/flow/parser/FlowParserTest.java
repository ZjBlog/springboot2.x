/*
* @(#)FlowParserTest.java 1.0 2020年6月6日
*
* Copyright (c) 2019 JDD. All rights reserved.
* PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
*/
package com.jd.jdd.yfk.flow.parser;

import java.io.InputStream;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import com.jd.jdd.yfk.flow.model.Flow;
import com.jd.jdd.yfk.flow.model.parser.FlowParser;
import com.jd.jdd.yfk.util.JsonUtil;

/**
 * 
 * TODO
 * 
 * @author liyuliang5
 * @version 1.0
 * @since 1.0
 */

public class FlowParserTest {

	private static final Logger logger = LoggerFactory.getLogger(FlowParserTest.class);

	@Test
	public void testParseFlow() throws Exception {
		PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
		Resource[] resources;
		InputStream is = null;
		resources = resolver.getResources("classpath:flow/flow001.json");
		for (Resource resource : resources) {
			try {
				logger.info("开始解析流程定义文件:" + resource.getURI());
				is = resource.getInputStream();
				String flowConfigStr = IOUtils.toString(is);
				List<Flow> flowList = FlowParser.parse(flowConfigStr);
				logger.info("解析完成，模型为:" + JsonUtil.toJSONString(flowList));
			} finally {
				if (is != null) {
					IOUtils.closeQuietly(is);
				}
			}
		}
	}
}

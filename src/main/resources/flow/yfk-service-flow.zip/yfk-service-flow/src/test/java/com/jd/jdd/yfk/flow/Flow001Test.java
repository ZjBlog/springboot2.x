package com.jd.jdd.yfk.flow;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jd.jdd.yfk.flow.engine.FlowParam;
import com.jd.jdd.yfk.flow.engine.FlowResult;
import com.jd.jdd.yfk.flow.engine.impl.FlowEngineImpl;
import com.jd.jdd.yfk.util.JsonUtil;

public class Flow001Test {
    
    public static final Logger logger = LoggerFactory.getLogger(Flow001Test.class);

    @Test
    public void testFlow001() {
        FlowEngineImpl flowEngine = new FlowEngineImpl();
        flowEngine.setFlowPath("classpath:flow/flow001.json");
        flowEngine.init();
        
        FlowParam param = new FlowParam();
        param.setFlowId("flow001");
        Map<String, Object> paramData = new HashMap<>();
        paramData.put("amount", new BigDecimal(80));
        param.setParam(paramData);
        param.setNodeIds(new String[] {"CONTRACT_SIGN"});
        
        FlowResult result = flowEngine.execute(param);
        logger.info("执行结果为:" + result);
    }
}

package com.jd.jdd.yfk.fsm.mockbiz;

public class WhitelistService {

    public boolean isWhitelist() {

        return true;
    }

    public boolean isWhitelistList() {

        return true;
    }
}

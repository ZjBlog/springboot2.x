package com.jd.jdd.yfk.flow.mockbiz.loan;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LoanBiz {

    private static final Logger logger = LoggerFactory.getLogger(LoanBiz.class);
    
    public void doLoan() {
        logger.info("完成放款指令发送");
    }
}

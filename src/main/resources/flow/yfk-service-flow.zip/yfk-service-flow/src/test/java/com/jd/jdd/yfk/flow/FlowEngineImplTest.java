package com.jd.jdd.yfk.flow;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jd.jdd.yfk.flow.engine.FlowParam;
import com.jd.jdd.yfk.flow.engine.FlowResult;
import com.jd.jdd.yfk.flow.engine.builder.FlowParamBuilder;
import com.jd.jdd.yfk.flow.engine.impl.FlowEngineImpl;
import com.jd.jdd.yfk.flow.model.Flow;
import com.jd.jdd.yfk.flow.model.action.ExecutorNodeAction;
import com.jd.jdd.yfk.flow.model.builder.FlowBuilder;
import com.jd.jdd.yfk.util.JsonUtil;

public class FlowEngineImplTest {
	
	public static final Logger logger = LoggerFactory.getLogger(FlowEngineImplTest.class);

    /**
     * 
     * 测试最基本的流程引擎.
     * 步骤：创建流程，执行流程，验证结果
     *
     */
	@Test
    public void testSample() {
    	//定义流程
        Flow flow = FlowBuilder.create("test", "testName")
        		//添加节点
        		.addNode("node1", new ExecutorNodeAction((nc, c) -> {logger.info("hello"); return "hello";}))
        		.build();
        FlowEngineImpl flowEngine = new FlowEngineImpl();
        flowEngine.addFlow(flow);
        
        // 创建执行入参数
        FlowParam param = FlowParamBuilder.create("test", "node1").nodeAction((context) -> {return null;}).build();
        // 执行流程
        FlowResult result = flowEngine.execute(param);
        // 打印结果
        logger.info("结果:" + result);
        
    }
}

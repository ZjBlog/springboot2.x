package com.jd.jdd.yfk.fsm;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;
public class Fsm001Test {

    
    public static final Logger logger = LoggerFactory.getLogger(Fsm001Test.class);

    /**
     * 
     * 测试创建流程实例
     * 状态 + 事件
     */
    @Test
    public void testFsm001Create() {
        FsmManager manager = new FsmManager();
        manager.setFsmPath("classpath:fsm/fsm003.json");
        manager.init();

        Fsm fsm = manager.getFsm("access_801011");
        
        //入参为空，默认为创建实例，从起始状态开始执行
        FsmParam param = new FsmParam();
        FsmResult result = fsm.run(param);
        logger.info(result.getState().getId());
        logger.info("执行结果为:" + result);
        // fsm run 和manager run 结果是一样的
//        param.setFsmId(fsm.getId());
//        FsmResult run = manager.run(param);
//        logger.info("执行结果为:{}" + run.getResult());


    }
    
    @Test
    public void testFsm001Run() {
        FsmManager manager = new FsmManager();
        manager.setFsmPath("classpath:fsm/fsm001.json");
        manager.init();

        Fsm fsm = manager.getFsm("access_80101");
        
        FsmParam param = new FsmParam();
        // 正常使用一般传入instanceId
        param.setCurrentStateId("COMPANY_AUTH");
        Map<String,Object> map=new HashMap<>();
        map.put("key",123);
        param.setEventId("SUBMIT_COMPANY_AUTH");
        param.setParam(map);
        FsmResult result = fsm.run(param);
        logger.info("执行后的节点为:" + result.getState().getId());
    }
}

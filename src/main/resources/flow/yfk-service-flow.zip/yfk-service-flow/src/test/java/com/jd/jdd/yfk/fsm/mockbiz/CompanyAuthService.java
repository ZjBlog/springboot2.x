package com.jd.jdd.yfk.fsm.mockbiz;

import com.jd.jdd.yfk.util.JsonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

public class CompanyAuthService {
    
    public static final Logger logger = LoggerFactory.getLogger(CompanyAuthService.class);

    public boolean isAuth() {
        return true;
    }
    public boolean isAuth1() {
        System.out.println("=====完成============");
        return true;
    }

    public void saveCompanyAuth(Map<String,Object> companyName) {
        logger.info("保存企业实名:" + JsonUtil.toJSONString(companyName));
    }

    public String isAuth2() {
        System.out.println("=====完成2============");
        return "true";
    }
    public MockTestEnum mock() {
        return MockTestEnum.TT;
    }


    public boolean isAuth4() {
        System.out.println("=====完成4============");
        return true;
    }

    public boolean isAuth5() {
        System.out.println("=====完成false============");
        return false;
    }
}

package com.jd.jdd.yfk.fsm;

import org.junit.Test;

import com.jd.jdd.yfk.fsm.Fsm;
import com.jd.jdd.yfk.fsm.FsmContext;
import com.jd.jdd.yfk.fsm.FsmParam;
import com.jd.jdd.yfk.fsm.builder.FsmBuilder;
import com.jd.jdd.yfk.fsm.model.Event;
import com.jd.jdd.yfk.fsm.model.State;
import com.jd.jdd.yfk.fsm.model.impl.EventImpl;
import com.jd.jdd.yfk.fsm.model.impl.StateImpl;

public class FsmTest {

	@Test
	public void testSample() {
		// 创建状态机
		State stateA = new StateImpl("A");
		State stateB = new StateImpl("B");
		Event event1 = new EventImpl("1");
		Fsm fsm = FsmBuilder.create("test").transition(stateA, event1, stateB).build();
		// 执行状态机
		FsmContext context = new FsmContext();
		context.setCurrentState(stateA);
		context.setCurrentEvent(event1);
		FsmParam param = new FsmParam();
		param.setContext(context);
		fsm.run(param);
	}
}

package com.jd.jdd.yfk.flow.mockbiz.limit;

import java.math.BigDecimal;

public class LimitBiz {

    public boolean judgeLimit(BigDecimal amount) {

        return amount.compareTo(new BigDecimal(100)) < 0;
    }
}

package com.jd.jdd.yfk.fsm.flow;

import com.jd.jdd.yfk.flow.engine.event.FlowEvent;
import com.jd.jdd.yfk.flow.engine.event.FlowEventListener;
import com.jd.jdd.yfk.flow.util.FlowEventTypes;
import com.jd.jdd.yfk.fsm.Fsm;
import com.jd.jdd.yfk.fsm.FsmContext;
import com.jd.jdd.yfk.fsm.FsmParam;

public class StateFlowEventListener implements FlowEventListener {

	private Fsm stateMachine;

	@Override
	public void on(FlowEvent flowEvent) {
		switch (flowEvent.getType()) {
		case FlowEventTypes.INIT_END: {
			stateMachine.run(null);
			flowEvent.getContext().put("XXX", null);
			break;
		}
		case FlowEventTypes.NODE_POST_START: {
			FsmContext context = flowEvent.getContext().get("XXX");
			FsmParam param = new FsmParam();
			param.setContext(context);
			stateMachine.run(param);
		}
		default: {
			// NOOP
		}
		}
	}

}

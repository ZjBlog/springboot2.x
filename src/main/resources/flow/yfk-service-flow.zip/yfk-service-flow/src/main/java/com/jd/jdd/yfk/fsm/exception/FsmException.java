package com.jd.jdd.yfk.fsm.exception;

public class FsmException extends RuntimeException{

}

package com.jd.jdd.yfk.flow.util;

public class FlowConstants {

	/**
	 * 参数键值
	 */
	public static final String PARAM_NODE_ACTION = "_NODE_ACTION";
	public static final String PARAM_NODE_MOVE = "_NODE_MOVE";
	

}

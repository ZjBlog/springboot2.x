package com.jd.jdd.yfk.fsm.listener;

import com.alibaba.fastjson.JSON;
import com.jd.jdd.yfk.fsm.event.FsmEvent;
import com.jd.jdd.yfk.fsm.event.FsmEventListener;
import com.jd.jdd.yfk.fsm.util.FsmConstants;
import com.jd.jdd.yfk.fsm.util.FsmEventTypes;
import org.apache.commons.lang3.tuple.Pair;

/**
 * @author zhangjun486
 * @version 1.0
 * @date 2020/6/28 15:25
 * @Description
 */
public class YfkAccessFsmListener implements FsmEventListener {
    @Override
    public Pair<String, Integer>[] getAcceptedEvents() {
        return new Pair[]{Pair.of(FsmEventTypes.FSM_MANAGER_START, FsmConstants.EVENT_ORDER_START),
                Pair.of(FsmEventTypes.FSM_START, FsmConstants.EVENT_ORDER_START + 1),
                Pair.of(FsmEventTypes.FSM_END, -FsmConstants.EVENT_ORDER_START - 1),
                Pair.of(FsmEventTypes.FSM_COMPLETE, FsmConstants.EVENT_ORDER_START)};
    }

    @Override
    public void on(FsmEvent event) {
        switch (event.getType()) {
            // 状态机manager调用事件
            case FsmEventTypes.FSM_MANAGER_START: {
                // TODO 如果为准入业务且传入的状态实例不为空，则查询状态机实例，如果实例ID与当前ID不一致，则考虑处理流程切换
                break;
            }
            // 状态机启动事件
            case FsmEventTypes.FSM_START: {
                System.out.println("=="+ JSON.toJSONString(event));
                System.out.println("==state:"+event.getContext().getCurrentState());
                // 查询或创建状态实例.
                // 1. 如果传入的accessNo为空，则创建准入实例(以用户级别锁定)；
                // 2. 锁定状态机实例
                // 3. 从数据库中查询准入实例
                // 4. 校验实例和用户是否一致，校验实例和产品是否一致，校验当前FsmId和实例FsmId是否一致（之后需要考虑流程切换的情况）
                // 5. 设置状态机初始状态，如果是创建则是Fsm的startState；否则是实例中的当前状态
                // 6. 如果未传入当前事件，则如果是创建，则交由FsmCommonListener处理，否则初始化为FsmConstants.COMMON_CHECK_EVENT
                // 7. TODO 校验事件和状态是否一致，暂不校验，如果不一致，则直接返回.
                System.out.println("=========================状态机启动");
                break;
            }
            // 状态机结束事件
            case FsmEventTypes.FSM_END: {
                // 1. 如果发生了状态变化，且下一个状态为风控审核，则调用风控审核接口
                // 2. 如果状态有变化，则持久化状态
                System.out.println("==end state:"+event.getContext().getCurrentState().getName());
                System.out.println("==pre state:"+event.getContext().getPreviousState().getName());
                System.out.println("=========================状态机完成");
                System.out.println("=="+JSON.toJSONString(event));
                break;
            }
            // 状态机完成事件
            case FsmEventTypes.FSM_COMPLETE: {
                // 1. 解锁状态实例
                System.out.println("=========================状态机结束");
                break;
            }
        }
    }
}

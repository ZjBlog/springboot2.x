package com.jd.jdd.yfk.flow.model;

import java.util.List;
import java.util.Map;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.jd.jdd.yfk.flow.engine.FlowContext;
import com.jd.jdd.yfk.flow.engine.event.FlowEventTrigger;

public class Flow {

	private String id;
	
	private String name;
	
	private String startNodeId;

	private List<FlowNode> nodeList;

	private Map<String, Object> properties;

	private Map<String, FlowNode> nodeMap;
	
	private FlowEventTrigger eventTrigger = new FlowEventTrigger();

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public List<FlowNode> getNodeList() {
		return nodeList;
	}

	public void setNodeList(List<FlowNode> nodeList) {
		this.nodeList = nodeList;
	}

	public Map<String, Object> getProperties() {
		return properties;
	}

	public void setProperties(Map<String, Object> properties) {
		this.properties = properties;
	}

	public Map<String, FlowNode> getNodeMap() {
		return nodeMap;
	}

	public void setNodeMap(Map<String, FlowNode> nodeMap) {
		this.nodeMap = nodeMap;
	}

	public void addProperty(String key, Object value) {
		if (this.properties == null) {
			properties = Maps.newHashMap();
		}
		properties.put(key, value);
	}

	public void addNode(FlowNode node) {
		if (this.nodeList == null) {
			this.nodeList = Lists.newArrayList();
		}
		if (this.nodeMap == null) {
			this.nodeMap = Maps.newHashMap();
		}
		this.nodeList.add(node);
		this.nodeMap.put(node.getId(), node);
	}

	public FlowNode getNode(String nodeId) {
		return this.nodeMap.get(nodeId);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

    public FlowEventTrigger getEventTrigger() {
        return eventTrigger;
    }

    public void setEventTrigger(FlowEventTrigger eventTrigger) {
        this.eventTrigger = eventTrigger;
    }
    
    public void triggerEvent(String eventType, FlowContext context) {
        this.eventTrigger.triggerEvent(eventType, context);
    }
    
    public void triggerEvent(String eventType, Object eventData, FlowContext context, boolean catchThrowable) {
        this.eventTrigger.triggerEvent(eventType, eventData, context, catchThrowable);
    }

    public String getStartNodeId() {
        return startNodeId;
    }

    public void setStartNodeId(String startNodeId) {
        this.startNodeId = startNodeId;
    }
    
    
    
}

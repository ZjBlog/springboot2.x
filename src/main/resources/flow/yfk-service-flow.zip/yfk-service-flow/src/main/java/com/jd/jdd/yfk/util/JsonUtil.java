package com.jd.jdd.yfk.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

/**
 * JSON工具类
 * 
 * @author liyuliang5
 *
 */
public class JsonUtil {

	private static ObjectMapper mapper = new ObjectMapper();
	private static final String STANDARD_FORMAT = "yyyy-MM-dd HH:mm:ss";

	static {
		mapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
	}

	public static String toJSONString(Object o) {
		return toJSONString(o, mapper);
	}

	public static String toJSONString(Object o, ObjectMapper mapper) {
		try {
			return mapper.writeValueAsString(o);
		} catch (JsonProcessingException e) {
			throw new RuntimeException(e);
		}
	}
	
	public static <T> T parseObject(String s, Class<T> clazz) {
		return parseObject(s, clazz, mapper);
	}

	public static <T> T parseObject(String s, Class<T> clazz, ObjectMapper mapper) {
		try {
			return mapper.readValue(s, clazz);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
}

package com.jd.jdd.yfk.flow.engine.impl;

import java.util.List;
import java.util.Map;
import java.util.Stack;
import java.util.concurrent.ConcurrentHashMap;

import com.jd.jdd.yfk.flow.engine.FlowContext;
import com.jd.jdd.yfk.flow.engine.FlowEngine;
import com.jd.jdd.yfk.flow.engine.FlowParam;
import com.jd.jdd.yfk.flow.engine.FlowResult;
import com.jd.jdd.yfk.flow.engine.event.FlowEventTrigger;
import com.jd.jdd.yfk.flow.model.Flow;
import com.jd.jdd.yfk.flow.model.NodeContext;

/**
 * 流程上下文，不支持多线程，仅限单线程引擎使用.
 * 
 * @author liyuliang5
 *
 */
public class FlowContextImpl implements FlowContext {
	/**
	 * 流程ID
	 */
	private String flowId;
	/**
	 * 流程定义
	 */
	private Flow flow;
	/**
	 * 流程入参
	 */
	private FlowParam param;
	/**
	 * 流程结果
	 */
	private FlowResult result;
	/**
	 * 事件触发器
	 */
	private FlowEventTrigger eventTrigger;
	
	private List<NodeContext> startNodes;
	/**
	 * 等待执行的节点上下文
	 */
	private Stack<NodeContext> nodeStack = new Stack<NodeContext>();

	/**
	 * 通用数据Map;
	 */
	private Map<String, Object> data = new ConcurrentHashMap<String, Object>();
	/**
	 * 流程引擎
	 */
	private FlowEngine flowEngine;

	public void put(String key, Object value) {
		data.put(key, value);
	}

	public <T> T get(String key) {
		return (T) data.get(key);
	}

	public void remove(String key) {
		data.remove(key);
	}

	public void addNodes(NodeContext[] nodes) {
		for (int i = 0; i < nodes.length; i++) {
			nodeStack.add(nodes[nodes.length - 1 - i]);
		}
	}

	/**
	 * 获取下一个执行的节点
	 */
	@Override
	public NodeContext getNextNode() {
		if (nodeStack == null) {
			return null;
		}
		if (nodeStack.isEmpty()) {
			return null;
		}
		return nodeStack.pop();
	}

	public FlowParam getParam() {
		return param;
	}

	public void setParam(FlowParam param) {
		this.param = param;
	}

	public FlowResult getResult() {
		return result;
	}

	public void setResult(FlowResult result) {
		this.result = result;
	}

	public String getFlowId() {
		return flowId;
	}

	public void setFlowId(String flowId) {
		this.flowId = flowId;
	}

	public Flow getFlow() {
		return flow;
	}

	public void setFlow(Flow flow) {
		this.flow = flow;
	}

	public FlowEventTrigger getEventTrigger() {
		return eventTrigger;
	}

	public void setEventTrigger(FlowEventTrigger eventTrigger) {
		this.eventTrigger = eventTrigger;
	}

	public Map<String, Object> getData() {
		return data;
	}

	public void setData(Map<String, Object> data) {
		this.data = data;
	}

    public FlowEngine getFlowEngine() {
        return flowEngine;
    }

    public void setFlowEngine(FlowEngine flowEngine) {
        this.flowEngine = flowEngine;
    }

    public List<NodeContext> getStartNodes() {
        return startNodes;
    }

    public void setStartNodes(List<NodeContext> startNodes) {
        this.startNodes = startNodes;
    }
	
}

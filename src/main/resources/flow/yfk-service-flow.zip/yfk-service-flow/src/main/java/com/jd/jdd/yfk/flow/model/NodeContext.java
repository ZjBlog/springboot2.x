package com.jd.jdd.yfk.flow.model;

import java.util.HashMap;
import java.util.Map;

public class NodeContext {

    public NodeContext() {
    }

    public NodeContext(String nodeId) {
        this.nodeId = nodeId;
    }

    private String nodeId;

    private NodeContext previousNode;

    private NodeContext[] nextNodes;

    private Object actionResult;

    /**
     * 通用数据Map;
     */
    private Map<String, Object> dataMap = new HashMap<String, Object>();

    public Object getActionResult() {
        return actionResult;
    }

    public void setActionResult(Object actionResult) {
        this.actionResult = actionResult;
    }

    public Map<String, Object> getDataMap() {
        return dataMap;
    }

    public void setDataMap(Map<String, Object> dataMap) {
        this.dataMap = dataMap;
    }

    public void put(String key, Object value) {
        dataMap.put(key, value);
    }

    public <T> T get(String key) {
        return (T) dataMap.get(key);
    }

    public void remove(String key) {
        dataMap.remove(key);
    }

    public void setNextNodeIds(String[] nextNodeIds) {
        nextNodes = new NodeContext[nextNodeIds.length];
        for (int i = 0; i < nextNodeIds.length; i++) {
            NodeContext nextNode = new NodeContext(nextNodeIds[i]);
            nextNode.setPreviousNode(this);
            nextNodes[i] = nextNode;
        }
    }

    public NodeContext[] getNextNodes() {
        return nextNodes;
    }

    public void setNextNodes(NodeContext[] nextNodes) {
        this.nextNodes = nextNodes;
    }

    public String getNodeId() {
        return nodeId;
    }

    public void setNodeId(String nodeId) {
        this.nodeId = nodeId;
    }

    public NodeContext getPreviousNode() {
        return previousNode;
    }

    public void setPreviousNode(NodeContext previousNode) {
        this.previousNode = previousNode;
    }

}

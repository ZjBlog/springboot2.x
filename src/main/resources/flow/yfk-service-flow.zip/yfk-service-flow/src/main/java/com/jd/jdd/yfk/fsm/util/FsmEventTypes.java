package com.jd.jdd.yfk.fsm.util;

public class FsmEventTypes {

	// 基础通用事件
    public static final String FSM_MANAGER_START = "FSM_MANAGER_START";
    public static final String FSM_MANAGER_END = "FSM_MANAGER_END";
    public static final String FSM_MANAGER_COMPLETE = "FSM_MANAGER_COMPLETE";
    
	public static final String FSM_START = "FSM_START";
	public static final String FSM_END = "FSM_END";
	public static final String FSM_COMPLETE = "FSM_COMPLETE";

	public static final String TST_START = "TST_START";
	public static final String TST_END = "TST_END";

}

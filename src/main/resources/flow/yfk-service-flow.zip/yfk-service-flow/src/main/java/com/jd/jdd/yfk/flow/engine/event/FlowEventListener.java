package com.jd.jdd.yfk.flow.engine.event;

import org.apache.commons.lang3.tuple.Pair;

public interface FlowEventListener {
	
    default Pair<String, Integer>[] getAcceptedEvents() {
        return null;
    }
    
    default String getId() {
        return this.getClass().getName();
    }

    public void on(FlowEvent flowEvent);
}

package com.jd.jdd.yfk.fsm.model.impl;

import java.util.List;

import com.jd.jdd.yfk.fsm.FsmContext;
import com.jd.jdd.yfk.fsm.model.Transition;
import com.jd.jdd.yfk.fsm.model.TransitionAction;
import com.jd.jdd.yfk.fsm.model.TransitionContext;
import com.jd.jdd.yfk.fsm.model.TransitionPostHandler;
import com.jd.jdd.yfk.fsm.model.TransitionPreHandler;

public class TransitionImpl implements Transition {
    
    private String fromId;
    
    private String eventId;
    
    private List<String> toIdList;
	
	private TransitionPreHandler preHandler;
	
	private TransitionAction action;
	
	private TransitionPostHandler postHandler;
	
	@Override
	public TransitionContext execute(TransitionContext transitionContext, FsmContext context) {
		if (preHandler != null) {
			boolean result = preHandler.preHandle(transitionContext, context);
			if (!result) {
				context.setCurrentEvent(null);
				return transitionContext;
			}
		}
		Object actionResult = null;
		if (action != null) {
			actionResult = action.execute(transitionContext, context);
		}
		if (context.isFirstTransition()) {
            context.setFirstTransitionActionResult(actionResult);
        }
        context.setTransitionActionResult(actionResult);
        
        String postStateId = null;
		if (postHandler != null) {
			postStateId = postHandler.postHandle(transitionContext, context);
		}
        if (context.isFirstTransition()) {
            context.setFirstTransitionPostState(context.getFsm().getState(postStateId));
        }
        context.setTransitionPostState(context.getFsm().getState(postStateId));
        if (postStateId != null) {
            context.setPreviousState(context.getCurrentState());
            context.setCurrentState(context.getFsm().getState(postStateId));
        }
        context.setPreviousEvent(context.getCurrentEvent());
        context.setCurrentEvent(null);
		return transitionContext;
	}

	public TransitionPreHandler getPreHandler() {
		return preHandler;
	}

	public void setPreHandler(TransitionPreHandler preHandler) {
		this.preHandler = preHandler;
	}

	public TransitionAction getAction() {
		return action;
	}

	public void setAction(TransitionAction action) {
		this.action = action;
	}

	public TransitionPostHandler getPostHandler() {
		return postHandler;
	}

	public void setPostHandler(TransitionPostHandler postHandler) {
		this.postHandler = postHandler;
	}

    public String getFromId() {
        return fromId;
    }

    public void setFromId(String fromId) {
        this.fromId = fromId;
    }

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public List<String> getToIdList() {
        return toIdList;
    }

    public void setToIdList(List<String> toIdList) {
        this.toIdList = toIdList;
    }
	
	

}

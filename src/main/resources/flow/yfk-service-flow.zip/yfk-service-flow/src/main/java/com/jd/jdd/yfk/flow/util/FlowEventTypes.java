package com.jd.jdd.yfk.flow.util;

/**
 * 流程类型
 * @author liyuliang5
 *
 */
public class FlowEventTypes {

	// 基础通用事件
	public static final String FLOW_START = "FLOW_START";
	public static final String FLOW_END = "FLOW_END";
	
	public static final String INIT_START = "INIT_START";
	public static final String INIT_END = "INIT_END";
	
	public static final String RUN_START = "RUN_START";
	public static final String RUN_END = "RUN_END";
	
	public static final String NODE_START = "NODE_START";
	public static final String NODE_END = "NODE_END";
	
	// 扩展通用事件
	public static final String NODE_PRE_START = "NODE_PRE_START";
	public static final String NODE_PRE_END = "NODE_PRE_END";
	public static final String NODE_ACTION_START = "NODE_ACTION_START";
	public static final String NODE_ACTION_END = "NODE_ACTION_END";
	public static final String NODE_POST_START = "NODE_POST_START";
	public static final String NODE_POST_END = "NODE_POST_END";
}

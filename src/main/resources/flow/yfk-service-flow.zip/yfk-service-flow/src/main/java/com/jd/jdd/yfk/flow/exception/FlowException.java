package com.jd.jdd.yfk.flow.exception;

public class FlowException extends RuntimeException {

}

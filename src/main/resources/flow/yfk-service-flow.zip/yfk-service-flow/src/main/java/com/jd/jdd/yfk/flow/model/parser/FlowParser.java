package com.jd.jdd.yfk.flow.model.parser;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jd.jdd.yfk.flow.model.Flow;
import com.jd.jdd.yfk.flow.model.NodeAction;
import com.jd.jdd.yfk.flow.model.NodePostHandler;
import com.jd.jdd.yfk.flow.model.NodePreHandler;
import com.jd.jdd.yfk.flow.model.action.ExpNodeAction;
import com.jd.jdd.yfk.flow.model.action.FlowNodeAction;
import com.jd.jdd.yfk.flow.model.node.NodeImpl;
import com.jd.jdd.yfk.flow.model.post.ConditionalNodePostHandler;
import com.jd.jdd.yfk.flow.model.post.ExpNodePostHandler;
import com.jd.jdd.yfk.flow.model.post.FixedNodePostHandler;
import com.jd.jdd.yfk.flow.model.pre.ExpNodePreHandler;
import com.jd.jdd.yfk.util.JsonUtil;
import com.jd.jdd.yfk.util.SpelHelper;

/**
 * 
 * 
 * 流程解析
 * 
 * @author liyuliang5
 * @version 1.0
 * @since 1.0
 */
public class FlowParser {

    private static final Logger logger = LoggerFactory.getLogger(FlowParser.class);

    /**
     * 解析json配置文件为模型.
     * 
     * @param data
     * @return
     */
    public static List<Flow> parse(String data) {
        List<Flow> flowList = new ArrayList<Flow>();
        parse(JsonUtil.parseObject(data, Map.class), flowList);
        return flowList;
    }
    
    
    public static Flow parse(Map<String, Object> map, List<Flow> flowList) {
        Flow flow = new Flow();
        flowList.add(flow);
        flow.setId((String) map.get("id"));
        flow.setName((String) map.get("name"));
        List<Map<String, Object>> nodeListConf = (List<Map<String, Object>>) map.get("nodes");
        for (Map<String, Object> nodeConf : nodeListConf) {
            NodeImpl node = new NodeImpl();
            node.setId((String) nodeConf.get("id"));
            node.setName((String) nodeConf.get("name"));
            boolean start = nodeConf.get("start") == null ? false : (Boolean) nodeConf.get("start");
            if (start) {
                flow.setStartNodeId(node.getId());
            }
            node.setProperties((Map<String, Object>) nodeConf.get("properties"));
            node.setPreHandler(parsePre((Map<String, Object>) nodeConf.get("pre")));
            node.setAction(parseAction((Map<String, Object>) nodeConf.get("action"), flowList));
            node.setPostHandler(parsePost((Map<String, Object>) nodeConf.get("post")));
            flow.addNode(node);
        }
        return flow;
    }

    public static NodePreHandler parsePre(Map<String, Object> pre) {
        if (pre == null) {
            return null;
        }
        String type = (String) pre.get("type");
        if ("create".equals(type) || pre.containsKey("createExp")) {
            String exp = (String) pre.get("createExp");
            NodePreHandler handler = SpelHelper.evalWithDefaultContext(exp, null, false);
            return handler;
        } else if ("exp".equals(type) || pre.containsKey("exp")) {
            String exp = (String) pre.get("exp");
            ExpNodePreHandler handler = new ExpNodePreHandler();
            handler.setExp(exp);
            return handler;
        }
        throw new IllegalArgumentException("参数非法" + pre);

    }

    public static NodeAction parseAction(Map<String, Object> action, List<Flow> flowList) {
        if (action == null) {
            return null;
        }
        String type = (String) action.get("type");
        if ("create".equals(type) || action.containsKey("createExp")) {
            String exp = (String) action.get("exp");
            NodeAction nodeAction = SpelHelper.evalWithDefaultContext(exp, null, false);
            return nodeAction;
        } else if ("exp".equals(type) || action.containsKey("exp")) {
            ExpNodeAction nodeAction = new ExpNodeAction();
            String exp = (String) action.get("exp");
            nodeAction.setExp(exp);
            return nodeAction;
        } else if ("flow".equals(type) || action.containsKey("flow")) {
            FlowNodeAction nodeAction = new FlowNodeAction();
            Flow flow = parse((Map<String, Object>) action.get("flow"), flowList);
            nodeAction.setFlowId(flow.getId());
            return nodeAction;
            
        }
        throw new IllegalArgumentException("参数非法" + action);
    }

    public static NodePostHandler parsePost(Map<String, Object> post) {
        if (post == null) {
            return null;
        }
        String type = (String) post.get("type");
        if ("create".equals(type) || post.containsKey("createExp")) {
            String exp = (String) post.get("createExp");
            NodePostHandler postHandler = SpelHelper.evalWithDefaultContext(exp, null, false);
            return postHandler;
        } else if ("exp".equals(type) || post.containsKey("exp")) {
            ExpNodePostHandler postHandler = new ExpNodePostHandler();
            String exp = (String) post.get("exp");
            postHandler.setExp(exp);
            return postHandler;
        } else if ("fixed".equals(type) || post.containsKey("to")) {
            Object nextStartId = post.get("to");
            String[] nextStart = (nextStartId instanceof String) ? new String[] { (String) nextStartId }
                    : (String[]) nextStartId;
            FixedNodePostHandler postHandler = new FixedNodePostHandler(nextStart);
            return postHandler;
        } else if ("condition".equals(type) || post.containsKey("conditions") || post.containsKey("when")) {
            List<Map<String, Object>> conditionList = null;
            if (post.containsKey("conditions")) {
             conditionList = (List<Map<String, Object>>) post.get("conditions");
            } else {
                conditionList = Arrays.asList(post);
            }
            ConditionalNodePostHandler postHandler = new ConditionalNodePostHandler(conditionList);
            return postHandler;

        }
        throw new IllegalArgumentException("参数非法" + post);
    }

}

package com.jd.jdd.yfk.fsm.event;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.jd.jdd.yfk.fsm.FsmContext;

public class FsmEventTrigger {

    public static final Logger logger = LoggerFactory.getLogger(FsmEventTrigger.class);

    public static final String NULL_KEY = null;

    private List<FsmEventListener> listenerList;

    private Map<String, TreeMap<Integer, List<FsmEventListener>>> listenerMap;

    public void addListener(FsmEventListener listener) {
        if (listenerList == null) {
            listenerList = Lists.newArrayList();
            listenerMap = Maps.newHashMap();
        }
        listenerList.add(listener);
        Pair<String, Integer>[] pairs = listener.getAcceptedEvents();
        if (pairs == null) {
            pairs = new Pair[] { Pair.of(NULL_KEY, 0) };
        }
        for (Pair<String, Integer> pair : pairs) {
            TreeMap<Integer, List<FsmEventListener>> map = listenerMap.get(pair.getLeft());
            if (map == null) {
                map = new TreeMap<Integer, List<FsmEventListener>>();
                listenerMap.put(pair.getLeft(), map);
            }
            List<FsmEventListener> listeners = map.get(pair.getRight());
            if (listeners == null) {
                listeners = Lists.newArrayList();
                map.put(pair.getRight(), listeners);
            }
            listeners.add(listener);
        }
    }

    public void triggerEvent(String eventType, FsmContext context) {
        triggerEvent(eventType, null, context, false);
    }

    public void triggerEvent(String eventType, Object eventData, FsmContext context, boolean catchThrowable) {
        if (listenerList == null || listenerList.size() == 0) {
            return;
        }
        
        FsmEvent event = new FsmEvent();
        event.setType(eventType);
        event.setData(eventData);
        event.setContext(context);
        
        
        TreeMap<Integer, List<FsmEventListener>> map = listenerMap.get(eventType);
        // 先执行>0
        if (map != null) {
            for (Entry<Integer, List<FsmEventListener>> entry : map.descendingMap().entrySet()) {
                if (entry.getKey() <= 0) {
                    break;
                }
                entry.getValue().forEach(listener -> onEvent(event, listener, catchThrowable));
            }
        }
        
        // 再执行有key且=0
        if (map != null) {
            List<FsmEventListener> keyZeroListeners = map.get(0);
            if (keyZeroListeners != null) {
                keyZeroListeners.forEach(listener -> onEvent(event, listener, catchThrowable));
            }
        }
        // 再执行null key
        TreeMap<Integer, List<FsmEventListener>> nullMap = listenerMap.get(NULL_KEY);
        if (nullMap != null) {
            List<FsmEventListener> nullZeroListeners = map.get(0);
            if (nullZeroListeners != null) {
                nullZeroListeners.forEach(listener -> onEvent(event, listener, catchThrowable));
            }
        }
        // 再执行<0
        if (map != null) {
            for (Entry<Integer, List<FsmEventListener>> entry : map.entrySet()) {
                if (entry.getKey() >= 0) {
                    break;
                }
                for (int i = 0; i < entry.getValue().size(); i++) {
                    onEvent(event, entry.getValue().get(entry.getValue().size() - 1 - i), catchThrowable);
                }
            } 
        }
    }
    
    private void onEvent(FsmEvent event, FsmEventListener listener, boolean catchThrowable) {
        if (!catchThrowable) {
            listener.on(event);
        } else {
            try {
                listener.on(event);
            } catch (Throwable t) {
                logger.error(listener.getClass().getName() + "执行异常，" + t.getMessage(), t);
            }
        }
    }

    public List<FsmEventListener> getListenerList() {
        return listenerList;
    }

    public void setListenerList(List<FsmEventListener> listenerList) {
        this.listenerList = listenerList;
    }
    
    

}

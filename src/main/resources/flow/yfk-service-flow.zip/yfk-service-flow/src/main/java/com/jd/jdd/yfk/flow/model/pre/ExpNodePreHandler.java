package com.jd.jdd.yfk.flow.model.pre;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.expression.spel.support.StandardEvaluationContext;

import com.jd.jdd.yfk.flow.engine.FlowContext;
import com.jd.jdd.yfk.flow.model.NodeContext;
import com.jd.jdd.yfk.flow.model.NodePreHandler;
import com.jd.jdd.yfk.flow.model.post.ExpNodePostHandler;
import com.jd.jdd.yfk.flow.util.FlowEngineSpelHelper;
import com.jd.jdd.yfk.util.SpelHelper;

public class ExpNodePreHandler implements NodePreHandler {

	private static final Logger logger = LoggerFactory.getLogger(ExpNodePostHandler.class);

	private String exp;

	public ExpNodePreHandler() {
	}

	public ExpNodePreHandler(String exp) {
		this.exp = exp;
	}

	@Override
	public boolean preHandle(NodeContext nodeContext, FlowContext context) {
		boolean result = FlowEngineSpelHelper.eval(exp, nodeContext, context);
		logger.info("计算结果为," + result);
		return result;
	}

	public String getExp() {
		return exp;
	}

	public void setExp(String exp) {
		this.exp = exp;
	}

}

package com.jd.jdd.yfk.fsm;

import com.jd.jdd.yfk.fsm.model.State;

public class FsmResult {
    
    /**
     * Fsm对象实例ID
     */
    private String instanceId;
    /**
     * Fsm对象实例
     */
    private Object instance;
    /**
     * Fsm所在状态
     */
    private State state;
    /**
     * 第一个事件的结果
     */
    private Object result;

    private FsmContext context;
    

    public String getInstanceId() {
        return instanceId;
    }

    public void setInstanceId(String instanceId) {
        this.instanceId = instanceId;
    }

    public Object getInstance() {
        return instance;
    }

    public void setInstance(Object instance) {
        this.instance = instance;
    }

    public State getState() {
        return state;
    }

    public void setState(State state) {
        this.state = state;
    }

    public FsmContext getContext() {
        return context;
    }

    public void setContext(FsmContext context) {
        this.context = context;
    }

    public Object getResult() {
        return result;
    }

    public void setResult(Object result) {
        this.result = result;
    }
    
}

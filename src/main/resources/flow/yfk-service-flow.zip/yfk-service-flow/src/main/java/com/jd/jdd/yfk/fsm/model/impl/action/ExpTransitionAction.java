package com.jd.jdd.yfk.fsm.model.impl.action;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jd.jdd.yfk.fsm.FsmContext;
import com.jd.jdd.yfk.fsm.model.TransitionAction;
import com.jd.jdd.yfk.fsm.model.TransitionContext;
import com.jd.jdd.yfk.fsm.util.FsmSpelHelper;
import com.jd.jdd.yfk.util.SpelHelper;

public class ExpTransitionAction  implements TransitionAction {

	private static final Logger logger = LoggerFactory.getLogger(ExpTransitionAction.class);

	private String exp;

	public ExpTransitionAction() {
	}

	public ExpTransitionAction(String exp) {
		this.exp = exp;
	}

	@Override
	public Object execute(TransitionContext transitionContext, FsmContext context) {
		Object result = FsmSpelHelper.eval(exp, transitionContext, context);
		return result;
	}

	public String getExp() {
		return exp;
	}

	public void setExp(String exp) {
		this.exp = exp;
	}

}

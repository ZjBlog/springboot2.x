package com.jd.jdd.yfk.flow.engine;

import java.util.List;
import java.util.Map;

public class FlowParam {

	private String flowId;

	private String[] nodeIds;

	private Object param;
	
	private FlowContext context;

	public String getFlowId() {
		return flowId;
	}

	public void setFlowId(String flowId) {
		this.flowId = flowId;
	}

	public String[] getNodeIds() {
		return nodeIds;
	}

	public void setNodeIds(String[] nodeIds) {
		this.nodeIds = nodeIds;
	}

	public void setNodeId(String nodeId) {
	    if (nodeId == null) {
	        return;
	    }
	    this.nodeIds = new String[] {nodeId};
	}
	
	public <T> T getParam() {
		return (T) param;
	}

	/**
	 * 要求paramData为Object[]或List
	 * @param <T>
	 * @param index
	 * @return
	 */
	public <T> T getParam(int index) {
		if (param == null) {
			return null;
		}
		if (param instanceof Object[]) {
			return (T) ((Object[]) param)[index];
		} else if (param instanceof List) {
			return (T) ((List) param).get(index);
		}
		throw new IllegalStateException("参数:" + param + "非索引类型");
	}
	
	/**
	 * 要求paramData为Map
	 * @param <T>
	 * @param key
	 * @return
	 */
	public <T> T getParam(String key) {
		if (param ==  null) {
			return null;
		}
		return (T) ((Map<String, Object>) param).get(key);
	}

	public void setParam(Object param) {
		this.param = param;
	}

    public FlowContext getContext() {
        return context;
    }

    public void setContext(FlowContext context) {
        this.context = context;
    }
	
	

}

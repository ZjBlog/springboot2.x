package com.jd.jdd.yfk.fsm.flow;

import com.jd.jdd.yfk.flow.engine.FlowContext;
import com.jd.jdd.yfk.flow.model.NodeContext;
import com.jd.jdd.yfk.flow.model.NodePostHandler;

/**
 * 节点后处理，根据当前状态得到下一个处理节点.
 * @author liyuliang5
 *
 */
public class StateNodePostHandler implements NodePostHandler {

	@Override
	public String[] postHandle(NodeContext nodeContext, FlowContext context) {
		// TODO Auto-generated method stub
		return null;
	}

}

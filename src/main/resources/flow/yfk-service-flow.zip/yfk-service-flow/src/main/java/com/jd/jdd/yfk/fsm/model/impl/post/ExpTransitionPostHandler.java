package com.jd.jdd.yfk.fsm.model.impl.post;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jd.jdd.yfk.fsm.FsmContext;
import com.jd.jdd.yfk.fsm.model.TransitionContext;
import com.jd.jdd.yfk.fsm.model.TransitionPostHandler;
import com.jd.jdd.yfk.fsm.util.FsmSpelHelper;
import com.jd.jdd.yfk.util.SpelHelper;

public class ExpTransitionPostHandler implements TransitionPostHandler {

	private static final Logger logger = LoggerFactory.getLogger(ExpTransitionPostHandler.class);

	private String exp;

	public ExpTransitionPostHandler() {
	}

	public ExpTransitionPostHandler(String exp) {
		this.exp = exp;
	}

	// exp
	//返回下一个状态
	@Override
	public String postHandle(TransitionContext transitionContext, FsmContext context) {
		logger.info("开始SPEL计算," + exp);
		String result = FsmSpelHelper.eval(exp, transitionContext, context);
		logger.info("计算结果为," + result);
		return result;
	}

	public String getExp() {
		return exp;
	}

	public void setExp(String exp) {
		this.exp = exp;
	}

}

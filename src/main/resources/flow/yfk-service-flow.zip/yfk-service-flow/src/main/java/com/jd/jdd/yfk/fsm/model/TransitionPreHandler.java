package com.jd.jdd.yfk.fsm.model;

import com.jd.jdd.yfk.fsm.FsmContext;

public interface TransitionPreHandler {

	public boolean preHandle(TransitionContext transitionContext, FsmContext context);
}

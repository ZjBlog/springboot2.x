package com.jd.jdd.yfk.flow.model;

import java.util.Map;

import com.jd.jdd.yfk.flow.engine.FlowContext;

public interface FlowNode {
    
    NodeContext execute(NodeContext nodeContext, FlowContext context);
    
    default String getId() {
       return null;
    }
    
    default String getName() {
        return null;
    }
    
    default Map<String, Object> getProperties() {
        return null;
    }
     default Map<String, Object> getProperty() {
         return null;
     }
    
    

}

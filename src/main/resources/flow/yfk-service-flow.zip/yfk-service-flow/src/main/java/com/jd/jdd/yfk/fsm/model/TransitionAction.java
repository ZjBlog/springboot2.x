package com.jd.jdd.yfk.fsm.model;

import com.jd.jdd.yfk.fsm.FsmContext;

public interface TransitionAction {

	//状态执行的结果
	public Object execute(TransitionContext transitionContext, FsmContext context);

}

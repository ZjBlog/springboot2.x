package com.jd.jdd.yfk.fsm.model;

import java.util.List;

import com.jd.jdd.yfk.fsm.FsmContext;

public interface Transition {
    
    public String getFromId();
    
    public String getEventId();
    
    public List<String> getToIdList();

    /**
     * 
     * 两个职责. 1执行Action结果保存到context中, 2. 得到下一迁移状态，设置到context中
     *
     * @param context
     */
	public TransitionContext execute(TransitionContext transitionContext, FsmContext context);
	
}

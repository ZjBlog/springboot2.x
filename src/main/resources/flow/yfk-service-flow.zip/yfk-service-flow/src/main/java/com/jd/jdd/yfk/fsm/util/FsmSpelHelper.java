package com.jd.jdd.yfk.fsm.util;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.expression.BeanFactoryResolver;
import org.springframework.context.expression.MapAccessor;
import org.springframework.expression.spel.support.StandardEvaluationContext;

import com.jd.jdd.yfk.flow.engine.FlowContext;
import com.jd.jdd.yfk.flow.model.NodeContext;
import com.jd.jdd.yfk.fsm.FsmContext;
import com.jd.jdd.yfk.fsm.model.TransitionContext;
import com.jd.jdd.yfk.util.JsonUtil;
import com.jd.jdd.yfk.util.SpelHelper;

/**
 * 
* 
* 封装Spel调用.
* 包装root
* @author liyuliang5
* @version 1.0
* @since 1.0
 */
public class FsmSpelHelper {
    
    private static final Logger logger = LoggerFactory.getLogger(FsmSpelHelper.class);
    
    public static StandardEvaluationContext evalContext = new StandardEvaluationContext();
    
    public static ApplicationContext applicationContext;
    
    static {
        evalContext.addPropertyAccessor(new MapAccessor());
    }
    

    public static <T>T eval(String exp, FsmContext fsmContext) {
        return eval(exp, null, fsmContext);
    }
    
    public static <T>T eval(String exp, TransitionContext transitionContext, FsmContext fsmContext) {
        logger.info("开始SPEL计算," + exp);
        Map<String, Object> root = new HashMap<>();
        root.put("transitionContext", transitionContext);
        root.put("context", fsmContext);
        root.put("param", fsmContext.getParam());
        Object result = SpelHelper.eval(exp, evalContext, root, true);
        logger.info("计算结果为:" + JsonUtil.toJSONString(result));
        return (T) result;
    }

    public static ApplicationContext getApplicationContext() {
        return applicationContext;
    }

    public static void setApplicationContext(ApplicationContext applicationContext) {
        FsmSpelHelper.applicationContext = applicationContext;
        evalContext.setBeanResolver(new BeanFactoryResolver(applicationContext));
    }
    
    
}

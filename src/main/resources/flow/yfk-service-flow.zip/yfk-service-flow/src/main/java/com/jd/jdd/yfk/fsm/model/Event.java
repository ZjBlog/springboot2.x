package com.jd.jdd.yfk.fsm.model;

public interface Event {

	public String getId();
	
	public String getName();
}

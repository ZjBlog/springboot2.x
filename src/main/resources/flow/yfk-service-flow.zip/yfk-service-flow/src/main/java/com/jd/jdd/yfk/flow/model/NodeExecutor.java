package com.jd.jdd.yfk.flow.model;

import com.jd.jdd.yfk.flow.engine.FlowContext;

public interface NodeExecutor<T> {

	public T execute(NodeContext nodeContext, FlowContext context);
}

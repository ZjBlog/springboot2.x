package com.jd.jdd.yfk.fsm;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.jd.jdd.yfk.fsm.event.FsmEventListener;
import com.jd.jdd.yfk.fsm.event.FsmEventTrigger;
import com.jd.jdd.yfk.fsm.parser.FsmParser;
import com.jd.jdd.yfk.fsm.util.FsmEventTypes;
import com.jd.jdd.yfk.fsm.util.FsmSpelHelper;
import com.jd.jdd.yfk.util.JsonUtil;
import com.jd.jdd.yfk.util.SpelHelper;

public class FsmManager implements ApplicationListener<ContextRefreshedEvent> {

    public static final Logger logger = LoggerFactory.getLogger(FsmManager.class);

    private List<Fsm> fsmList = Lists.newArrayList();

    private Map<String, Fsm> fsmMap = Maps.newHashMap();

    private String fsmPath;

    private FsmEventTrigger eventTrigger = new FsmEventTrigger();

    private List<FsmEventListener> listeners;
    
    private ApplicationContext applicationContext;

    private volatile boolean inited = false;

    public void init() {
        if (inited) {
            return;
        }
        if (applicationContext != null) {
            FsmSpelHelper.setApplicationContext(applicationContext);
            SpelHelper.setApplicationContext(applicationContext);
        }
        
        PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        Resource[] resources;
        InputStream is = null;
        try {
            resources = resolver.getResources(fsmPath);
            for (Resource resource : resources) {
                try {
                    logger.info("开始解析状态机定义文件:" + resource.getURI());
                    is = resource.getInputStream();
                    String fsmConfigStr = IOUtils.toString(is);
                    Fsm fsm = FsmParser.parse(fsmConfigStr);
                    logger.info("解析完成，模型为:" + JsonUtil.toJSONString(fsm));
                    fsmMap.put(fsm.getId(), fsm);
                } finally {
                    if (is != null) {
                        IOUtils.closeQuietly(is);
                    }
                }
            }
        } catch (IOException e) {
            throw new RuntimeException("状态配置文件加载失败", e);
        } finally {
            if (is != null) {
                IOUtils.closeQuietly(is);
            }
        }
        if (listeners != null) {
            listeners.forEach(listener -> eventTrigger.addListener(listener));
        }
        inited = true;
    }

    public void add(Fsm fsm) {
        if (!fsmMap.containsKey(fsm.getId())) {
            fsmList.add(fsm);
            fsmMap.put(fsm.getId(), fsm);
        }
    }

    public Fsm getFsm(String id) {
        return fsmMap.get(id);
    }

    public FsmResult run(FsmParam param) {
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("param", param);
        eventTrigger.triggerEvent(FsmEventTypes.FSM_MANAGER_START, data, null, false);
        try {
            Fsm fsm = getFsm(param.getFsmId());
            FsmResult result = fsm.run(param);
            data.put("result", result);
            eventTrigger.triggerEvent(FsmEventTypes.FSM_MANAGER_END, data, null, false);
            return result;
        } finally {
            eventTrigger.triggerEvent(FsmEventTypes.FSM_MANAGER_COMPLETE, data, null, true);
        }
    }

    public String getFsmPath() {
        return fsmPath;
    }

    public void setFsmPath(String fsmPath) {
        this.fsmPath = fsmPath;
    }

    public List<FsmEventListener> getListeners() {
        return listeners;
    }

    public void setListeners(List<FsmEventListener> listeners) {
        this.listeners = listeners;
    }

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        if (event.getApplicationContext().getParent() == null) {
            FsmSpelHelper.setApplicationContext(event.getApplicationContext());
            this.applicationContext = event.getApplicationContext();
            init();
        }

    }

}

package com.jd.jdd.yfk.flow.engine.builder;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.jd.jdd.yfk.flow.common.FlowExecutor;
import com.jd.jdd.yfk.flow.engine.FlowParam;
import com.jd.jdd.yfk.flow.util.FlowConstants;

public class FlowParamBuilder {

	private FlowParam param;
	
	public static FlowParamBuilder create(String flowId, String nodeId) {
		FlowParam param = new FlowParam();
		param.setFlowId(flowId);
		param.setNodeIds(new String[] {nodeId});
		FlowParamBuilder builder = new FlowParamBuilder();
		builder.param = param;
		return builder;
	}
	
	public FlowParamBuilder nodeAction(FlowExecutor<? extends Object> action) {
		putParam(FlowConstants.PARAM_NODE_ACTION, action);
		return this;
	}
	
	public FlowParamBuilder nodeMove(FlowExecutor<? extends Object> move) {
		putParam(FlowConstants.PARAM_NODE_MOVE, move);
		return this;
	}
	
	public FlowParamBuilder putParam(String key, Object value) {
		if (param.getParam() == null) {
			param.setParam(Maps.newHashMap());
		}
		((Map<String, Object>) param.getParam()).put(key, value);
		return this;
	}
	
	public FlowParamBuilder addParam(Object value) {
		if (param.getParam() == null) {
			param.setParam(Lists.newArrayList());
		}
		((List<Object>) param.getParam()).add(value);
		return this;
	}
	
	public FlowParamBuilder addParams(Object... values) {
		if (param.getParam() == null) {
			param.setParam(Lists.newArrayList());
		}
		((List<Object>) param.getParam()).addAll(Arrays.asList(values));
		return this;
	}
	
	public FlowParamBuilder paramObject(Object o) {
		param.setParam(o);
		return this;
	}
	
	public FlowParam build() {
		return param;
	}
	
	
	
	
	
}

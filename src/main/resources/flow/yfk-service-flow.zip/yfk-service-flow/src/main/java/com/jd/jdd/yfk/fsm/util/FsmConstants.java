package com.jd.jdd.yfk.fsm.util;

import com.jd.jdd.yfk.fsm.model.Event;
import com.jd.jdd.yfk.fsm.model.impl.EventImpl;

public class FsmConstants {

    public static final Event COMMON_ENTER_EVENT = new EventImpl("_state_enter", "状态进入事件");
    public static final Event COMMON_CHECK_EVENT = new EventImpl("_state_check", "状态检查事件");

    public static final int EVENT_ORDER_START = 10000;

}

package com.jd.jdd.yfk.flow.engine;

import java.util.List;
import java.util.Map;

import com.jd.jdd.yfk.flow.model.Flow;
import com.jd.jdd.yfk.flow.model.NodeContext;

/**
 * 流程上下文
 * @author liyuliang5
 *
 */
public interface FlowContext {
    
    public List<NodeContext> getStartNodes();

    public void setStartNodes(List<NodeContext> startNodes);

	public void put(String key, Object value);

	public <T> T get(String key);

	public void remove(String key);
	
	public void setData(Map<String, Object> data);
	
	public Map<String, Object> getData();
	
	public void addNodes(NodeContext[] nodes);
	
	public NodeContext getNextNode();

	public FlowParam getParam();

	public void setParam(FlowParam param);

	public FlowResult getResult();

	public void setResult(FlowResult result);

	public String getFlowId();

	public void setFlowId(String flowId);

	public Flow getFlow();

	public void setFlow(Flow flow);
	
	public FlowEngine getFlowEngine();
	
	public void setFlowEngine(FlowEngine flowEngine);

}

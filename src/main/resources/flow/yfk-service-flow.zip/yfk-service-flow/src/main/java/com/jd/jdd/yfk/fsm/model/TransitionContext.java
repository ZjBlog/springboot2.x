package com.jd.jdd.yfk.fsm.model;

import java.util.HashMap;
import java.util.Map;

public class TransitionContext {

    /**
     * 通用数据Map;
     */
    private Map<String, Object> dataMap = new HashMap<String, Object>();

    public Map<String, Object> getDataMap() {
        return dataMap;
    }

    public void setDataMap(Map<String, Object> dataMap) {
        this.dataMap = dataMap;
    }
    
    public void put(String key, Object value) {
        dataMap.put(key, value);
    }

    public <T> T get(String key) {
        return (T) dataMap.get(key);
    }

    public void remove(String key) {
        dataMap.remove(key);
    }
}

package com.jd.jdd.yfk.flow.model.action;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jd.jdd.yfk.flow.engine.FlowContext;
import com.jd.jdd.yfk.flow.model.NodeAction;
import com.jd.jdd.yfk.flow.model.NodeContext;
import com.jd.jdd.yfk.flow.util.FlowEngineSpelHelper;

public class ExpNodeAction implements NodeAction {
	
	private static final Logger logger = LoggerFactory.getLogger(ExpNodeAction.class);
	
    private String exp;
    
    public ExpNodeAction() {
	}
    public ExpNodeAction(String exp) {
    	this.exp = exp;
    }

	@Override
	public <T>T execute(NodeContext nodeContext, FlowContext context) {
		Object result = FlowEngineSpelHelper.eval(exp, nodeContext, context);
		return (T) result;
	}
	public String getExp() {
		return exp;
	}
	public void setExp(String exp) {
		this.exp = exp;
	}
	
	

}

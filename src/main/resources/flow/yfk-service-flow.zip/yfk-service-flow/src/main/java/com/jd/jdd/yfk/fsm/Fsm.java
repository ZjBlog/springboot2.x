package com.jd.jdd.yfk.fsm;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jd.jdd.yfk.fsm.event.FsmEventListener;
import com.jd.jdd.yfk.fsm.event.FsmEventTrigger;
import com.jd.jdd.yfk.fsm.model.Event;
import com.jd.jdd.yfk.fsm.model.State;
import com.jd.jdd.yfk.fsm.model.Transition;
import com.jd.jdd.yfk.fsm.model.TransitionContext;
import com.jd.jdd.yfk.fsm.util.FsmEventTypes;

public class Fsm {

    public static final Logger logger = LoggerFactory.getLogger(Fsm.class);

    private String id;

    private String name;

    private List<State> stateList = new ArrayList<State>();

    private String startStateId;

    private Map<String, State> stateMap = new HashMap<String, State>();

    private List<Event> eventList = new ArrayList<Event>();

    private Map<String, Event> eventMap = new HashMap<String, Event>();

    private List<Transition> transitionList = new ArrayList<Transition>();

    private Map<String, Transition> transitionMap = new HashMap<String, Transition>();

    private FsmEventTrigger eventTrigger = new FsmEventTrigger();


    /**
     * 执行状态机时，外层负责查找执行哪个状态机
     *
     * @param event
     * @param context
     */
    public FsmResult run(FsmParam param) {
        FsmContext context = initContext(param);
        Throwable throwable = null;
        try {
            eventTrigger.triggerEvent(FsmEventTypes.FSM_START, context);
            // 初始化起始状态
            initStartState(context);
            while (true) {
                State currentState = context.getCurrentState();
                Event event = context.getCurrentEvent();
                logger.info("当前节点:" + currentState.getId() + ", 当前事件" + (event == null ? null : event.getId()));
                if (event == null) {
                    break;
                }
                String transitionKey = createTransitionKey(currentState, event);
                Transition transition = transitionMap.get(transitionKey);
                if (transition == null) {
                    logger.warn("未找到transition, currentState:" + currentState.getId() + " currentEvent:" + event.getId()
                            + ",退出");
                    break;
                }
                beforeTransition(context);
                eventTrigger.triggerEvent(FsmEventTypes.TST_START, context);
                TransitionContext transitionContext = new TransitionContext();
                transition.execute(transitionContext, context);
                eventTrigger.triggerEvent(FsmEventTypes.TST_END, context);
                afterTransition(context);

            }
            eventTrigger.triggerEvent(FsmEventTypes.FSM_END, context);
            return wrapResult(context);
        } catch (Throwable t) {
            throwable = t;
            logger.error(t.getMessage(), t);
            throw t;
        } finally {
            eventTrigger.triggerEvent(FsmEventTypes.FSM_COMPLETE, throwable, context, true);
        }
    }

    /**
     * 初始化Context，只需要确保context中有事件和节点便可执行
     *
     * @param param
     * @return
     */
    public FsmContext initContext(FsmParam param) {
        FsmContext context = param.getContext() != null ? param.getContext() : new FsmContext();
        FsmResult result = new FsmResult();
        context.setParam(param);
        context.setResult(result);
        result.setContext(context);
        context.setFsm(this);
        if (param.getCurrentStateId() != null) {
            context.setCurrentState(getState(param.getCurrentStateId()));
        }
        if (param.getEventId() != null) {
            context.setCurrentEvent(getEvent(param.getEventId()));
        }
        return context;
    }

    private State initStartState(FsmContext context) {
        State currentState = context.getCurrentState();
        if (currentState == null) {
            currentState = getState(startStateId);
            context.setCurrentState(currentState);
        }
        return currentState;
    }

    public FsmResult wrapResult(FsmContext context) {
        FsmResult result = context.getResult();
        result.setInstance(context.getStateInstance());
        result.setInstanceId(context.getStateInstanceId());
        result.setState(context.getCurrentState());
        result.setResult(context.getFirstTransitionActionResult());
        return result;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public List<State> getStateList() {
        return stateList;
    }

    public void setStateList(List<State> stateList) {
        this.stateList = stateList;
    }

    public List<Event> getEventList() {
        return eventList;
    }

    public void setEventList(List<Event> eventList) {
        this.eventList = eventList;
    }

    public void addState(State state) {
        if (!stateMap.containsKey(state.getId())) {
            stateMap.put(state.getId(), state);
            stateList.add(state);
        }
    }

    public State getState(String stateId) {
        return stateMap.get(stateId);
    }

    public void addEvent(Event event) {
        if (!eventMap.containsKey(event.getId())) {
            eventMap.put(event.getId(), event);
            eventList.add(event);
        }
    }

    public Event getEvent(String eventId) {
        return eventMap.get(eventId);
    }

    public void addTransition(Transition transition) {
        String fromId = transition.getFromId();
        String eventId = transition.getEventId();
        if (fromId == null) {
            throw new RuntimeException("fromId不能为空");
        }
        if (eventId == null) {
            throw new RuntimeException("eventId不能为空");
        }
        transitionList.add(transition);
        transitionMap.put(createTransitionKey(fromId, eventId), transition);
    }

    /**
     * 迁移前处理
     *
     * @param context
     */
    public void beforeTransition(FsmContext context) {
        context.setTransitionActionResult(null);
        context.setTransitionPostState(null);
    }

    /**
     * 迁移后处理
     *
     * @param context
     */
    public void afterTransition(FsmContext context) {
        if (context.isFirstTransition()) {
            context.setFirstTransition(false);
        }
    }

    private String createTransitionKey(State from, Event event) {
        return "state_" + from.getId() + "_event_" + event.getId();
    }

    private String createTransitionKey(String fromId, String eventId) {
        return "state_" + fromId + "_event_" + eventId;
    }

    public void addListener(FsmEventListener listener) {
        eventTrigger.addListener(listener);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Transition> getTransitionList() {
        return transitionList;
    }

    public void setTransitionList(List<Transition> transitionList) {
        this.transitionList = transitionList;
    }

    public String getStartStateId() {
        return startStateId;
    }

    public void setStartStateId(String startStateId) {
        this.startStateId = startStateId;
    }

    public FsmEventTrigger getEventTrigger() {
        return eventTrigger;
    }

    public void setEventTrigger(FsmEventTrigger eventTrigger) {
        this.eventTrigger = eventTrigger;
    }

}

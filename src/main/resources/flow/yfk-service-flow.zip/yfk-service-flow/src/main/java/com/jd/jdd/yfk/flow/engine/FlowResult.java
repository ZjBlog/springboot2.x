package com.jd.jdd.yfk.flow.engine;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FlowResult {

    private FlowContext context;

    private Object result;

    public FlowContext getContext() {
        return context;
    }

    public void setContext(FlowContext context) {
        this.context = context;
    }

    public Object getResult() {
        return result;
    }

    public void setResult(Object result) {
        this.result = result;
    }

    /**
     * 
     * 放入结果. putResult和addResult只能调用一个
     *
     * @param key
     * @param value
     */
    public synchronized void putResult(String key, Object value) {
        if (result == null) {
            result = new HashMap<String, Object>();
        }
        ((Map<String, Object>) result).put(key, value);
    }
    /**
     * 
     * 放入结果. putResult和addResult只能调用一个
     *
     * @param value
     */
    public synchronized void addResult(Object value) {
        if (result == null) {
            result = new ArrayList<Object>();
        }
        ((List<Object>) result).add(value);
    }
    
    public synchronized <T>T getResult(String key) {
        if (result == null) {
            return null;
        }
        return (T) ((Map<String, Object>) result).get(key);
    }
    
    public synchronized <T>T getResult(int index) {
        if (result == null) {
            return null;
        }
        return (T) ((List<Object>) result).get(index);
    }    
    
}

package com.jd.jdd.yfk.fsm.builder;

import java.util.Arrays;
import java.util.List;

import com.google.common.collect.Lists;
import com.jd.jdd.yfk.fsm.Fsm;
import com.jd.jdd.yfk.fsm.event.FsmEventListener;
import com.jd.jdd.yfk.fsm.listener.FsmCommonListener;
import com.jd.jdd.yfk.fsm.model.Event;
import com.jd.jdd.yfk.fsm.model.State;
import com.jd.jdd.yfk.fsm.model.Transition;
import com.jd.jdd.yfk.fsm.model.TransitionAction;
import com.jd.jdd.yfk.fsm.model.TransitionPostHandler;
import com.jd.jdd.yfk.fsm.model.TransitionPreHandler;
import com.jd.jdd.yfk.fsm.model.builder.TransitionBuilder;
import com.jd.jdd.yfk.fsm.model.impl.EventImpl;
import com.jd.jdd.yfk.fsm.model.impl.StateImpl;

public class FsmBuilder {

    private Fsm fsm;

    private FsmBuilder() {
        // NOOP
    }

    public static FsmBuilder create(String id) {
        return create(id, null);
    }

    public static FsmBuilder create(String id, String name) {
        FsmBuilder builder = new FsmBuilder();
        Fsm fsm = new Fsm();
        fsm.setId(id);
        fsm.setName(name);
        builder.fsm = fsm;
        return builder;
    }

    public FsmBuilder state(State state) {
        fsm.addState(state);
        return this;
    }
    
    public FsmBuilder startState(State state) {
        fsm.addState(state);
        fsm.setStartStateId(state.getId());
        return this;
    }
    
    public FsmBuilder startState(String stateId) {
        return startState(addState(stateId));
    }
    
    

    public FsmBuilder state(String id, String name) {
        return state(id, name, false);
    }
    
    public FsmBuilder state(String id, String name, boolean start) {
        StateImpl state = new StateImpl(id, name);
        fsm.addState(state);
        if (start) {
            fsm.setStartStateId(id);
        }
        return this;
    }

    public FsmBuilder states(State[] states) {
        for (State state : states) {
            fsm.addState(state);
        }
        return this;
    }

    public FsmBuilder event(Event event) {
        fsm.addEvent(event);
        return this;
    }

    public FsmBuilder event(String id, String name) {
        EventImpl event = new EventImpl(id, name);
        fsm.addEvent(event);
        return this;
    }

    public FsmBuilder events(Event[] events) {
        for (Event event : events) {
            fsm.addEvent(event);
        }
        return this;
    }

    public FsmBuilder transition(String fromId, String eventId, String toId) {
        State from = addState(fromId);
        Event event = addEvent(eventId);
        State to = addState(toId);
        transition(from, event, to);
        return this;
    }

    public FsmBuilder transition(State from, Event event, State to) {
        TransitionBuilder builder = TransitionBuilder.create();
        builder.fromId(from.getId()).eventId(event.getId()).to(to)
                .toIdList(to == null ? null : Arrays.asList(to.getId()));
        Transition transition = builder.build();
        fsm.addState(from);
        fsm.addState(to);
        fsm.addEvent(event);
        fsm.addTransition(transition);
        return this;
    }

    public FsmBuilder transition(Transition transition) {
        addState(transition.getFromId());
        addEvent(transition.getEventId());
        if (transition.getToIdList() != null) {
            for (String toId : transition.getToIdList()) {
                addState(toId);
            }
        }
        fsm.addTransition(transition);
        return this;
    }

    public FsmBuilder transition(String fromId, String eventId, List<String> toIdList, TransitionPreHandler preHandler,
            TransitionAction action, TransitionPostHandler postHandler) {
        State from = addState(fromId);
        Event event = addEvent(eventId);

        List<State> toList = Lists.newArrayList();
        if (toIdList != null) {
            for (String toId : toIdList) {
                State to = addState(toId);
                toList.add(to);
            }
        }
        transition(from, event, toList, preHandler, action, postHandler);
        return this;
    }

    public FsmBuilder transition(State from, Event event, List<State> toList, TransitionPreHandler preHandler,
            TransitionAction action, TransitionPostHandler postHandler) {
        fsm.addState(from);
        fsm.addEvent(event);
        for (State to : toList) {
            fsm.addState(to);
        }

        List<String> toIdList = Lists.newArrayList();
        for (State to : toList) {
            toIdList.add(to.getId());
        }
        TransitionBuilder builder = TransitionBuilder.create();
        builder.fromId(from.getId()).eventId(event.getId()).toIdList(toIdList).preHandler(preHandler).action(action)
                .postHandler(postHandler);
        Transition transition = builder.build();
        fsm.addTransition(transition);
        return this;
    }
    
    public FsmBuilder listener(FsmEventListener listener) {
        fsm.addListener(listener);
        return this;
    }

    public Fsm build() {
        return fsm;
    }
    
    private State addState(String stateId) {
        if (stateId == null) {
            return null;
        }
        State state = fsm.getState(stateId);
        if (state == null) {
            state = new StateImpl(stateId);
            fsm.addState(state);
        }
        return state;
    }
    
    private Event addEvent(String eventId) {
        Event event = fsm.getEvent(eventId);
        if (event == null) {
            event = new EventImpl(eventId);
            fsm.addEvent(event);
        }
        return event;
    }

}

package com.jd.jdd.yfk.fsm.model.impl.pre;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jd.jdd.yfk.fsm.FsmContext;
import com.jd.jdd.yfk.fsm.model.TransitionContext;
import com.jd.jdd.yfk.fsm.model.TransitionPreHandler;
import com.jd.jdd.yfk.fsm.util.FsmSpelHelper;

public class ExpTransitionPreHandler implements TransitionPreHandler {

	private static final Logger logger = LoggerFactory.getLogger(ExpTransitionPreHandler.class);

	private String exp;

	public ExpTransitionPreHandler() {
	}

	public ExpTransitionPreHandler(String exp) {
		this.exp = exp;
	}

	@Override
	public boolean preHandle(TransitionContext transitionContext, FsmContext context) {
		boolean result = FsmSpelHelper.eval(exp, transitionContext, context);
		return result;
	}

	public String getExp() {
		return exp;
	}

	public void setExp(String exp) {
		this.exp = exp;
	}

}

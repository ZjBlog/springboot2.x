package com.jd.jdd.yfk.flow.common;

import com.jd.jdd.yfk.flow.engine.FlowContext;

public interface FlowExecutor<T> {

	public T execute(FlowContext context);
}

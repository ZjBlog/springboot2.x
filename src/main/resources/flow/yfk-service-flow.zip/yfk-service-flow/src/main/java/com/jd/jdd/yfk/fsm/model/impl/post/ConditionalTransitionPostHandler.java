package com.jd.jdd.yfk.fsm.model.impl.post;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jd.jdd.yfk.fsm.FsmContext;
import com.jd.jdd.yfk.fsm.model.TransitionContext;
import com.jd.jdd.yfk.fsm.model.TransitionPostHandler;
import com.jd.jdd.yfk.fsm.util.FsmSpelHelper;
import com.jd.jdd.yfk.util.SpelHelper;

public class ConditionalTransitionPostHandler implements TransitionPostHandler {

	private static final Logger logger = LoggerFactory.getLogger(ConditionalTransitionPostHandler.class);

	private List<Map<String, Object>> branchList;

	public ConditionalTransitionPostHandler() {
	}

	public ConditionalTransitionPostHandler(Map<String, Object> branch) {
		this.branchList = Arrays.asList(branch);
	}

	public ConditionalTransitionPostHandler(List<Map<String, Object>> branchList) {
		this.branchList = branchList;
	}

	//条件判断
	@Override
	public String postHandle(TransitionContext transitionContext, FsmContext context) {
		for (Map<String, Object> branch : branchList) {
			String when = (String) branch.get("when");
			logger.info("开始SPEL计算:" + when);
			boolean result = FsmSpelHelper.eval(when, context);
			if (result) {
				String next = (String) branch.get("to");
				return next;
			}
		}
		return null;
	}

}
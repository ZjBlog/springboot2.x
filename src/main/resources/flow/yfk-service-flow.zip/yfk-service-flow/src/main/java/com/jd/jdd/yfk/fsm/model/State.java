package com.jd.jdd.yfk.fsm.model;

import java.util.Map;

public interface State {
	

	public String getId();
	
	public String getName();
	
	public Map<String, Object> getProperties();
	
}

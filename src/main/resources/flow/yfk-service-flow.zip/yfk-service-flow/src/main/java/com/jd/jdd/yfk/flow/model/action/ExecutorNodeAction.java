package com.jd.jdd.yfk.flow.model.action;

import com.jd.jdd.yfk.flow.engine.FlowContext;
import com.jd.jdd.yfk.flow.model.NodeAction;
import com.jd.jdd.yfk.flow.model.NodeContext;
import com.jd.jdd.yfk.flow.model.NodeExecutor;

public class ExecutorNodeAction implements NodeAction {

	private NodeExecutor executor;

	public ExecutorNodeAction() {
	}

	public ExecutorNodeAction(NodeExecutor executor) {
		this.executor = executor;
	}

	@Override
	public <T> T execute(NodeContext nodeContext, FlowContext context) {
		Object result = executor.execute(nodeContext, context);
		return (T) result;

	}

	public NodeExecutor getExecutor() {
		return executor;
	}

	public void setExecutor(NodeExecutor executor) {
		this.executor = executor;
	}

}

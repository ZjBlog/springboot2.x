/*
* @(#)StateMachinerParser.java 1.0 2020年6月6日
*
* Copyright (c) 2019 JDD. All rights reserved.
* PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
*/
package com.jd.jdd.yfk.fsm.parser;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jd.jdd.yfk.fsm.Fsm;
import com.jd.jdd.yfk.fsm.builder.FsmBuilder;
import com.jd.jdd.yfk.fsm.event.FsmEventListener;
import com.jd.jdd.yfk.fsm.model.Transition;
import com.jd.jdd.yfk.fsm.model.TransitionAction;
import com.jd.jdd.yfk.fsm.model.TransitionPostHandler;
import com.jd.jdd.yfk.fsm.model.TransitionPreHandler;
import com.jd.jdd.yfk.fsm.model.builder.TransitionBuilder;
import com.jd.jdd.yfk.fsm.model.impl.StateImpl;
import com.jd.jdd.yfk.fsm.model.impl.action.ExpTransitionAction;
import com.jd.jdd.yfk.fsm.model.impl.post.ConditionalTransitionPostHandler;
import com.jd.jdd.yfk.fsm.model.impl.post.ExpTransitionPostHandler;
import com.jd.jdd.yfk.fsm.model.impl.post.FixedTransitionPostHandler;
import com.jd.jdd.yfk.fsm.model.impl.pre.ExpTransitionPreHandler;
import com.jd.jdd.yfk.util.JsonUtil;
import com.jd.jdd.yfk.util.SpelHelper;

/**
 * 
 * 状态机解析器
 * 
 * @author liyuliang5
 * @version 1.0
 * @since 1.0
 */

public class FsmParser {

    private static final Logger logger = LoggerFactory.getLogger(FsmParser.class);
    
    /**
     * 解析json配置文件为模型.
     * 
     * @param data
     * @return
     */
    public static Fsm parse(String data) {
        Map<String, Object> map = JsonUtil.parseObject(data, Map.class);
        String fsmId = (String) map.get("id");
        String fsmName = (String) map.get("name");
        FsmBuilder builder = FsmBuilder.create(fsmId, fsmName);
        // 解析状态
        List<Map<String, Object>> states = (List<Map<String, Object>>) map.get("states");
        if (states != null) {
            for (Map<String, Object> state : states) {
                boolean start = Boolean.TRUE.equals(state.get("start"));
                StateImpl stateInfo = new StateImpl((String) state.get("id"), (String) state.get("name"),
                        (Map<String, Object>) state.get("properties"));
                if (start) {
                    builder.startState(stateInfo);
                } else {
                    builder.state(stateInfo);
                }
            }
        }
        // 解析事件
        List<Map<String, Object>> events = (List<Map<String, Object>>) map.get("events");
        if (events != null) {
            for (Map<String, Object> event : events) {
                builder.event((String) event.get("id"), (String) event.get("name"));
            }
        }
        // 解析迁移
        List<Map<String, Object>> transitions = (List<Map<String, Object>>) map.get("transitions");
        for (Map<String, Object> transition : transitions) {
            TransitionBuilder transBuilder = TransitionBuilder.create();
            Map<String, Object> pre = (Map<String, Object>) transition.get("pre");
            TransitionPreHandler preHandler = parsePre(pre);
            Map<String, Object> action = (Map<String, Object>) transition.get("action");
            TransitionAction transAction = parseAction(action);
            Map<String, Object> post = (Map<String, Object>) transition.get("post");
            TransitionPostHandler postHandler = parsePost(post);

            //toList 逻辑上没用到
            // 配置文件中 states 和events 可以去掉  有了toList
            List<String> toList = (List<String>) transition.get("toList");
            
            Object from = transition.get("from");
            List<String> froms = from instanceof String ? Arrays.asList((String) from) : (List<String>) from;
            Object event = transition.get("event");
            List<String> evts = event instanceof String ? Arrays.asList((String) event) : (List<String>) event;
            for (String fromId : froms) {
                for (String eventId : evts) {
                    Transition trans = transBuilder.fromId(fromId)
                            .eventId(eventId).toIdList(toList).preHandler(preHandler)
                            .action(transAction).postHandler(postHandler).build();
                    builder.transition(trans);
                }
            }

        }
        // 解析监听器
        List<Map<String, Object>> listeners = (List<Map<String, Object>>)map.get("listeners");
        if (listeners != null) {
            for (Map<String, Object> listener : listeners) {
                String type = (String) listener.get("type");
                if ("create".equals(type) || listener.containsKey("createExp")) {
                    String exp = (String) listener.get("createExp");
                    FsmEventListener eventListener = SpelHelper.evalWithDefaultContext(exp, null, false);
                    builder.listener(eventListener);
                }
            }
        }
        

        return builder.build();
    }

    //pre 前置
    public static TransitionPreHandler parsePre(Map<String, Object> pre) {
        if (pre == null) {
            return null;
        }
        String type = (String) pre.get("type");
        if ("create".equals(type) || pre.containsKey("createExp")) {
            String exp = (String) pre.get("createExp");
            TransitionPreHandler handler = SpelHelper.evalWithDefaultContext(exp, null, false);
            return handler;
        } else if ("exp".equals(type) || pre.containsKey("exp")) {
            ExpTransitionPreHandler transAction = new ExpTransitionPreHandler();
            String exp = (String) pre.get("exp");
            transAction.setExp(exp);
            return transAction;
        }
        throw new IllegalArgumentException("参数非法" + pre);

    }

    //action
    public static TransitionAction parseAction(Map<String, Object> action) {
        if (action == null) {
            return null;
        }
        String type = (String) action.get("type");
        if ("create".equals(type) || action.containsKey("createExp")) {
            String exp = (String) action.get("exp");
            TransitionAction nodeAction = SpelHelper.evalWithDefaultContext(exp, null, false);
            return nodeAction;
        } else if ("exp".equals(type) || action.containsKey("exp")) {
            ExpTransitionAction transAction = new ExpTransitionAction();
            String exp = (String) action.get("exp");
            transAction.setExp(exp);
            return transAction;
        }
        throw new IllegalArgumentException("参数非法" + action);
    }

    //post
    public static TransitionPostHandler parsePost(Map<String, Object> post) {
        if (post == null) {
            return null;
        }
        String type = (String) post.get("type");
        if ("create".equals(type) || post.containsKey("createExp")) {
            String exp = (String) post.get("createExp");
            TransitionPostHandler postHandler = SpelHelper.evalWithDefaultContext(exp, null, false);
            return postHandler;
        } else if ("exp".equals(type) || post.containsKey("exp")) {
            ExpTransitionPostHandler postHandler = new ExpTransitionPostHandler();
            String exp = (String) post.get("exp");
            postHandler.setExp(exp);
            return postHandler;
        } else if ("fixed".equals(type) || post.containsKey("to")) {
            String nextStateId = (String) post.get("to");
            FixedTransitionPostHandler postHandler = new FixedTransitionPostHandler(nextStateId);
            return postHandler;
        } else if ("condition".equals(type) || post.containsKey("conditions") || post.containsKey("when")) {
            List<Map<String, Object>> conditionList = null;
            if (post.containsKey("conditions")) {
                conditionList = (List<Map<String, Object>>) post.get("conditions");
            } else {
                conditionList = Arrays.asList(post);
            }
            ConditionalTransitionPostHandler postHandler = new ConditionalTransitionPostHandler(conditionList);
            return postHandler;

        }
        throw new IllegalArgumentException("参数非法" + post);
    }
}

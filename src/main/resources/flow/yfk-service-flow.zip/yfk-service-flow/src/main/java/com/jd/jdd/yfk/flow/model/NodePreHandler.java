package com.jd.jdd.yfk.flow.model;

import java.util.Map;

import com.jd.jdd.yfk.flow.engine.FlowContext;

public interface NodePreHandler {
	
	boolean preHandle(NodeContext nodeContext, FlowContext context);
	
    default Map<String, Object> getProperties() {
        return null;
    }

    default <T> T getProperties(String key) {
        return null;
    }
}

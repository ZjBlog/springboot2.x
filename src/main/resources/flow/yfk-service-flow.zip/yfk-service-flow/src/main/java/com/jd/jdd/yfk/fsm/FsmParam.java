package com.jd.jdd.yfk.fsm;

/**
 * 
* 
* 状态机请求参数.
* 创建实例时无必传. listener负责创建实例.
* 执行时必传eventId.
* 在状态机构建完上下文后，必须有currentState和event
* 
* @author liyuliang5
* @version 1.0
* @since 1.0
 */
public class FsmParam {
    
    public enum OpType {
        /**创建状态实例*/
        CREATE, 
        /**执行状态机*/
        EXECUTE
    }
    
    /**
     * 操作类型
     */
    private OpType opType = OpType.EXECUTE;
    
    private String fsmId;
    
    private String bizType;
    
    private String instanceId;
    
    private Object instance;
    
    private String currentStateId;
    
    private String eventId;
    
    private FsmContext context;
    
    private Object param;

    public String getInstanceId() {
        return instanceId;
    }

    public void setInstanceId(String instanceId) {
        this.instanceId = instanceId;
    }

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public FsmContext getContext() {
        return context;
    }

    public void setContext(FsmContext context) {
        this.context = context;
    }

    public Object getInstance() {
        return instance;
    }

    public void setInstance(Object instance) {
        this.instance = instance;
    }

    public String getCurrentStateId() {
        return currentStateId;
    }

    public void setCurrentStateId(String currentStateId) {
        this.currentStateId = currentStateId;
    }
    
    public <T>T getParam() {
        return (T) param;
    }

    public void setParam(Object param) {
        this.param = param;
    }

    public OpType getOpType() {
        return opType;
    }

    public void setOpType(OpType opType) {
        this.opType = opType;
    }

    public String getFsmId() {
        return fsmId;
    }

    public void setFsmId(String fsmId) {
        this.fsmId = fsmId;
    }

    public String getBizType() {
        return bizType;
    }

    public void setBizType(String bizType) {
        this.bizType = bizType;
    }
    
}

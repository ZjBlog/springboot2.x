package com.jd.jdd.yfk.fsm.event;

import org.apache.commons.lang3.tuple.Pair;

public interface FsmEventListener {
	
	/**
	 * 返回能够接收的事件及各事件的执行权重数. 一方面为了快速执行，另一方面为了选择执行顺序.
	 * 执行时首选选择接收的监听者，然后先执行权重为正数的，按从大到小，一样的按添加的顺序
	 * 再执行权重为空的，按照添加的顺序，
	 * 再执行权重为负数的，按从小到大，一样的按添加的倒序
	 * TODO
	 *
	 * @return
	 */
	default Pair<String, Integer>[] getAcceptedEvents() {
		return null;
	}
	
	default String getId() {
	    return this.getClass().getName();
	}

    public void on(FsmEvent event);
}

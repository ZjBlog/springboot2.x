package com.jd.jdd.yfk.flow.model.post;

import com.jd.jdd.yfk.flow.engine.FlowContext;
import com.jd.jdd.yfk.flow.model.NodeContext;
import com.jd.jdd.yfk.flow.model.NodePostHandler;

public class FixedNodePostHandler implements NodePostHandler {

	private String[] nodeIds;

	public FixedNodePostHandler() {
	}

	public FixedNodePostHandler(String nodeId) {
		nodeIds = new String[] { nodeId };
	}

	public FixedNodePostHandler(String[] nodeIds) {
		this.nodeIds = nodeIds;
	}

	@Override
	public String[] postHandle(NodeContext nodeContext, FlowContext context) {
		return nodeIds;
	}

}
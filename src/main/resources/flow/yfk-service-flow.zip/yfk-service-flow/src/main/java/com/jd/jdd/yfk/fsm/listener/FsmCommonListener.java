package com.jd.jdd.yfk.fsm.listener;

import org.apache.commons.lang3.tuple.Pair;

import com.jd.jdd.yfk.fsm.event.FsmEvent;
import com.jd.jdd.yfk.fsm.event.FsmEventListener;
import com.jd.jdd.yfk.fsm.util.FsmConstants;
import com.jd.jdd.yfk.fsm.util.FsmEventTypes;

public class FsmCommonListener implements FsmEventListener {
    
    public Pair<String, Integer>[] getAcceptedEvents() {
        return new Pair[] {Pair.of(FsmEventTypes.FSM_START, FsmConstants.EVENT_ORDER_START),
                Pair.of(FsmEventTypes.TST_END, -FsmConstants.EVENT_ORDER_START)};
    }

    @Override
    public void on(FsmEvent event) {
        switch (event.getType()) {
        // 如果状态机启动后未传入事件，则默认为创建实例时的节点进入事件
        // TODO: 专门加一个状态进入和退出的事件扩展性更好
        case FsmEventTypes.FSM_START : {
            if (event.getContext().getCurrentEvent() == null) {
                event.getContext().setCurrentEvent(FsmConstants.COMMON_ENTER_EVENT);
            }
            System.out.println("===============fsm_start");
            break;
        }
        // 如果迁移结束后有下一个状态，但没有下一个事件，则默认为状态进入事件
        //下一个事件一定没有 执行的时候给设置为null了
        case FsmEventTypes.TST_END: {
            if ( event.getContext().getCurrentEvent() == null && event.getContext().getTransitionPostState() != null) {
                event.getContext().setCurrentEvent(FsmConstants.COMMON_ENTER_EVENT);
            }
            System.out.println("===============TST_END");
            break;
        }
        }

    }

}

package com.jd.jdd.yfk.fsm.model.impl.post;

import com.jd.jdd.yfk.fsm.FsmContext;
import com.jd.jdd.yfk.fsm.model.TransitionContext;
import com.jd.jdd.yfk.fsm.model.TransitionPostHandler;

public class FixedTransitionPostHandler implements TransitionPostHandler {

    private String nextStateId;

    public FixedTransitionPostHandler(String nextStateId) {
        this.nextStateId = nextStateId;
    }


    //强制去哪个状态节点
    @Override
    public String postHandle(TransitionContext transitionContext, FsmContext context) {
        return nextStateId;
    }

}

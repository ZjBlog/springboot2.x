package com.jd.jdd.yfk.flow.model.post;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.expression.spel.support.StandardEvaluationContext;

import com.jd.jdd.yfk.flow.engine.FlowContext;
import com.jd.jdd.yfk.flow.model.NodeContext;
import com.jd.jdd.yfk.flow.model.NodePostHandler;
import com.jd.jdd.yfk.flow.util.FlowEngineSpelHelper;
import com.jd.jdd.yfk.util.SpelHelper;

public class ExpNodePostHandler implements NodePostHandler {
	
	private static final Logger logger = LoggerFactory.getLogger(ExpNodePostHandler.class);

    private static StandardEvaluationContext evalContext = new StandardEvaluationContext();

    private String exp;
    
    public ExpNodePostHandler() {
	}
    public ExpNodePostHandler(String exp) {
    	this.exp = exp;
    }

	@Override
	public String[] postHandle(NodeContext nodeContext, FlowContext context) {
		String[] result = FlowEngineSpelHelper.eval(exp, nodeContext, context);
		return result;
	}
	public String getExp() {
		return exp;
	}
	public void setExp(String exp) {
		this.exp = exp;
	}
	
	

}

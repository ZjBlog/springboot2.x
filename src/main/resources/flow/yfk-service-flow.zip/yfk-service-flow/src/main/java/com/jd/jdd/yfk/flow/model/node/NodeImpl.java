package com.jd.jdd.yfk.flow.model.node;

import java.util.Map;

import com.jd.jdd.yfk.flow.engine.FlowContext;
import com.jd.jdd.yfk.flow.model.FlowNode;
import com.jd.jdd.yfk.flow.model.NodeAction;
import com.jd.jdd.yfk.flow.model.NodeContext;
import com.jd.jdd.yfk.flow.model.NodePostHandler;
import com.jd.jdd.yfk.flow.model.NodePreHandler;
import com.jd.jdd.yfk.flow.util.FlowEventTypes;

public class NodeImpl implements FlowNode {

    private String id;

    private String name;

    private Map<String, Object> properties;

    private NodePreHandler preHandler;

    private NodeAction action;

    private NodePostHandler postHandler;

    @Override
    public NodeContext execute(NodeContext nodeContext, FlowContext context) {
        if (preHandler != null) {
            context.getFlow().triggerEvent(FlowEventTypes.NODE_PRE_START, context);
            boolean result = preHandler.preHandle(nodeContext, context);
            context.getFlow().triggerEvent(FlowEventTypes.NODE_PRE_END, context);
            if (!result) {
                return nodeContext;
            }
        }
        if (action != null) {
            context.getFlow().triggerEvent(FlowEventTypes.NODE_ACTION_START, context);
            Object result = action.execute(nodeContext, context);
            nodeContext.setActionResult(result);
            context.getFlow().triggerEvent(FlowEventTypes.NODE_ACTION_END, context);
        }
        if (postHandler != null) {
            context.getFlow().triggerEvent(FlowEventTypes.NODE_POST_START, context);
            String[] nextNodeIds = postHandler.postHandle(nodeContext, context);
            context.getFlow().triggerEvent(FlowEventTypes.NODE_POST_END, context);
            nodeContext.setNextNodeIds(nextNodeIds);
        }
        return nodeContext;
    }

    public NodeAction getAction() {
        return action;
    }

    public void setAction(NodeAction action) {
        this.action = action;
    }

    public NodePreHandler getPreHandler() {
        return preHandler;
    }

    public void setPreHandler(NodePreHandler preHandler) {
        this.preHandler = preHandler;
    }

    public NodePostHandler getPostHandler() {
        return postHandler;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPostHandler(NodePostHandler postHandler) {
        this.postHandler = postHandler;
    }

    @Override
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Map<String, Object> getProperties() {
        return properties;
    }

    public void setProperties(Map<String, Object> properties) {
        this.properties = properties;
    }

}

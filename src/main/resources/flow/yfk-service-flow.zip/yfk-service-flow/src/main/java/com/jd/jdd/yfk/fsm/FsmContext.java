package com.jd.jdd.yfk.fsm;

import java.util.HashMap;
import java.util.Map;

import com.jd.jdd.yfk.fsm.model.Event;
import com.jd.jdd.yfk.fsm.model.State;

public class FsmContext {

    /**
     * 当前状态
     */
    private State currentState;
    /**
     * 上一状态
     */
    private State previousState;
    /**
     * 当前事件
     */
    private Event currentEvent;
    /**
     * 上一事件
     */
    private Event previousEvent;

    private Object stateInstance;

    private String stateInstanceId;

    private Fsm fsm;

    FsmParam param;

    FsmResult result;

    private boolean firstTransition = true;
    /**
     * 第一个迁移的状态
     */
    private State firstTransitionPostState;
    /**
     * 第一个迁移的结果
     */
    private Object firstTransitionActionResult;
    /**
     * 上一迁移结果状态
     */
    private State transitionPostState;
    /**
     * 上一个迁移执行结果
     */
    private Object transitionActionResult;

    private Map<String, Object> data = new HashMap<String, Object>();

    public Object getStateInstance() {
        return stateInstance;
    }

    public void setStateInstance(Object stateInstance) {
        this.stateInstance = stateInstance;
    }

    public String getStateInstanceId() {
        return stateInstanceId;
    }

    public void setStateInstanceId(String stateInstanceId) {
        this.stateInstanceId = stateInstanceId;
    }

    public State getCurrentState() {
        return currentState;
    }

    public void setCurrentState(State currentState) {
        this.currentState = currentState;
    }

    public Event getCurrentEvent() {
        return currentEvent;
    }

    public void setCurrentEvent(Event currentEvent) {
        this.currentEvent = currentEvent;
    }

    public Fsm getFsm() {
        return fsm;
    }

    public void setFsm(Fsm fsm) {
        this.fsm = fsm;
    }

    public Map<String, Object> getData() {
        return data;
    }

    public void setData(Map<String, Object> data) {
        this.data = data;
    }

    public <T> T getData(String key) {
        return (T) data.get(key);
    }

    public void putData(String key, Object value) {
        data.put(key, value);
    }

    public FsmParam getParam() {
        return param;
    }

    public void setParam(FsmParam param) {
        this.param = param;
    }

    public FsmResult getResult() {
        return result;
    }

    public void setResult(FsmResult result) {
        this.result = result;
    }

    public boolean isFirstTransition() {
        return firstTransition;
    }

    public void setFirstTransition(boolean firstTransition) {
        this.firstTransition = firstTransition;
    }

    public Object getTransitionActionResult() {
        return transitionActionResult;
    }

    public void setTransitionActionResult(Object transitionActionResult) {
        this.transitionActionResult = transitionActionResult;
    }

    public State getPreviousState() {
        return previousState;
    }

    public void setPreviousState(State previousState) {
        this.previousState = previousState;
    }

    public Event getPreviousEvent() {
        return previousEvent;
    }

    public void setPreviousEvent(Event previousEvent) {
        this.previousEvent = previousEvent;
    }

    public Object getFirstTransitionActionResult() {
        return firstTransitionActionResult;
    }

    public void setFirstTransitionActionResult(Object firstTransitionActionResult) {
        this.firstTransitionActionResult = firstTransitionActionResult;
    }

    public State getFirstTransitionPostState() {
        return firstTransitionPostState;
    }

    public void setFirstTransitionPostState(State firstTransitionPostState) {
        this.firstTransitionPostState = firstTransitionPostState;
    }

    public State getTransitionPostState() {
        return transitionPostState;
    }

    public void setTransitionPostState(State transitionPostState) {
        this.transitionPostState = transitionPostState;
    }




}

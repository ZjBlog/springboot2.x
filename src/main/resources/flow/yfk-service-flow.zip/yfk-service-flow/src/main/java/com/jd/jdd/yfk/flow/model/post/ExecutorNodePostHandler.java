package com.jd.jdd.yfk.flow.model.post;

import com.jd.jdd.yfk.flow.engine.FlowContext;
import com.jd.jdd.yfk.flow.model.NodeContext;
import com.jd.jdd.yfk.flow.model.NodeExecutor;
import com.jd.jdd.yfk.flow.model.NodePostHandler;

public class ExecutorNodePostHandler implements NodePostHandler {
	
	private NodeExecutor<? extends Object> executor;
	
	public ExecutorNodePostHandler(NodeExecutor<? extends Object> executor) {
		this.executor = executor;
	}

	@Override
	public String[] postHandle(NodeContext nodeContext, FlowContext context) {
		String[] result = (String[]) executor.execute(nodeContext, context);
		return result;
	}

}

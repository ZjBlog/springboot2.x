package com.jd.jdd.yfk.flow.engine;

public interface FlowEngine {

    public FlowResult execute(FlowParam param);
}

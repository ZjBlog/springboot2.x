package com.jd.jdd.yfk.flow.model.post;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.expression.spel.support.StandardEvaluationContext;

import com.jd.jdd.yfk.flow.engine.FlowContext;
import com.jd.jdd.yfk.flow.model.NodeContext;
import com.jd.jdd.yfk.flow.model.NodePostHandler;
import com.jd.jdd.yfk.flow.util.FlowEngineSpelHelper;
import com.jd.jdd.yfk.util.SpelHelper;

public class ConditionalNodePostHandler implements NodePostHandler {
	
	private static final Logger logger = LoggerFactory.getLogger(ConditionalNodePostHandler.class);

	private static StandardEvaluationContext evalContext = new StandardEvaluationContext();

	private List<Map<String, Object>> branchList;

	public ConditionalNodePostHandler() {
	}

	public ConditionalNodePostHandler(Map<String, Object> branch) {
		this.branchList = Arrays.asList(branch);
	}

	public ConditionalNodePostHandler(List<Map<String, Object>> branchList) {
		this.branchList = branchList;
	}

	@Override
	public String[]  postHandle(NodeContext nodeContext, FlowContext context) {
		for (Map<String, Object> branch : branchList) {
			String when = (String) branch.get("when");
			boolean result =  FlowEngineSpelHelper.eval(when, nodeContext, context);
			if (result) {
				Object next = branch.get("to");
				if (next instanceof String) {
					return new String[] { (String) next };
				}
				return (String[]) next;
			}
		}
		return null;
	}

}
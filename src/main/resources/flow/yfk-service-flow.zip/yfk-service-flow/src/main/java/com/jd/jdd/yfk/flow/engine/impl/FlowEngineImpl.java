package com.jd.jdd.yfk.flow.engine.impl;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.jd.jdd.yfk.flow.engine.FlowContext;
import com.jd.jdd.yfk.flow.engine.FlowEngine;
import com.jd.jdd.yfk.flow.engine.FlowParam;
import com.jd.jdd.yfk.flow.engine.FlowResult;
import com.jd.jdd.yfk.flow.model.Flow;
import com.jd.jdd.yfk.flow.model.FlowNode;
import com.jd.jdd.yfk.flow.model.NodeContext;
import com.jd.jdd.yfk.flow.model.parser.FlowParser;
import com.jd.jdd.yfk.flow.util.FlowEngineSpelHelper;
import com.jd.jdd.yfk.flow.util.FlowEventTypes;
import com.jd.jdd.yfk.fsm.util.FsmSpelHelper;
import com.jd.jdd.yfk.util.JsonUtil;
import com.jd.jdd.yfk.util.SpelHelper;

public class FlowEngineImpl implements FlowEngine, ApplicationListener<ContextRefreshedEvent> {

    public static final Logger logger = LoggerFactory.getLogger(FlowEngineImpl.class);

    private List<Flow> flowList = Lists.newArrayList();

    private Map<String, Flow> flowMap = Maps.newHashMap();

    private String flowPath;

    private volatile boolean inited;

    private ApplicationContext applicationContext;

    public void init() {
        if (inited) {
            return;
        }
        if (applicationContext != null) {
            FlowEngineSpelHelper.setApplicationContext(applicationContext);
            SpelHelper.setApplicationContext(applicationContext);
        }

        PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        Resource[] resources;
        InputStream is = null;
        try {
            resources = resolver.getResources(flowPath);
            for (Resource resource : resources) {
                try {
                    logger.info("开始解析流程定义文件:" + resource.getURI());
                    is = resource.getInputStream();
                    String flowConfigStr = IOUtils.toString(is);
                    List<Flow> flowList = FlowParser.parse(flowConfigStr);
                    logger.info("解析完成，模型为:" + JsonUtil.toJSONString(flowList));
                    flowList.forEach(flow -> flowMap.put(flow.getId(), flow));
                } finally {
                    if (is != null) {
                        IOUtils.closeQuietly(is);
                    }
                }
            }
        } catch (IOException e) {
            throw new RuntimeException("流程配置文件加载失败", e);
        } finally {
            if (is != null) {
                IOUtils.closeQuietly(is);
            }
        }
        inited = true;
    }

    /**
     * 执行流程时，外层负责查找执行哪个流程 流程执行. 1. 找到要执行的流程节点 2. 执行流程节点 3. 执行状态转移 4.
     * 如果无下一个流程节点，则返回；否则跳到第2步
     */
    @Override
    public FlowResult execute(FlowParam param) {
        logger.info("开始执行流程，入参:" + JsonUtil.toJSONString(param));
        // 初始化上下文
        FlowContext context = initContext(param);
        // 查找流程定义
        Flow flow = findFlow(context);

        flow.triggerEvent(FlowEventTypes.FLOW_START, context);

        // 初始化
        init(context);
        // 执行
        run(context);

        flow.triggerEvent(FlowEventTypes.FLOW_END, context);

        return wrapResult(context);
    }

    private FlowContext initContext(FlowParam param) {
        FlowContext context = param.getContext() != null ? param.getContext() : new FlowContextImpl();
        if (context.getParam() == null) {
            context.setParam(param);
        }
        if (context.getResult() == null) {
            FlowResult result = new FlowResult();
            context.setResult(result);
            result.setContext(context);
        }
        context.setFlowId(param.getFlowId());
        context.setFlowEngine(this);
        return context;
    }

    /**
     * 
     * 多节点执行 多节点支持有如下三种方案： 1. 单线程深度优先（建议） 2. 单线程广度优先 3. 多线程并发执行（效率高，但实现复杂）
     * 本次实现单线程深度优先
     *
     * @param context
     */
    private void run(FlowContext context) {
        Flow flow = context.getFlow();
        flow.triggerEvent(FlowEventTypes.RUN_START, context);
        NodeContext nextNode;
        // 只要流程队列中非空便一直执行
        while ((nextNode = context.getNextNode()) != null) {
            logger.info("开始执行节点:" + nextNode.getNodeId());
            FlowNode node = context.getFlow().getNode(nextNode.getNodeId());
            flow.triggerEvent(FlowEventTypes.NODE_START, context);
            // 执行节点
            node.execute(nextNode, context);
            NodeContext[] nextNodes = nextNode.getNextNodes();
            flow.triggerEvent(FlowEventTypes.NODE_END, context);
            // 编排下一个节点
            if (nextNodes != null) {
                context.addNodes(nextNodes);
            }

            if (logger.isInfoEnabled()) {
                StringBuilder builder = new StringBuilder();
                if (nextNodes != null) {
                    for (NodeContext n : nextNodes) {
                        builder.append(n.getNodeId() + ",");
                    }
                }
                logger.info("返回的节点为:" + builder.toString());
            }
        }
        flow.triggerEvent(FlowEventTypes.RUN_END, context);
    }

    /**
     * 
     * 查找流程定义
     *
     * @return
     */
    private Flow findFlow(FlowContext context) {
        Flow flow = flowMap.get(context.getFlowId());
        context.setFlow(flow);
        return flow;
    }

    /**
     * 
     * 初始化
     *
     * @param param
     */
    private void init(FlowContext context) {
        context.getFlow().triggerEvent(FlowEventTypes.INIT_START, context);
        String[] nodeIds = context.getParam().getNodeIds();
        if (nodeIds == null || nodeIds.length == 0) {
            nodeIds = new String[] { context.getFlow().getStartNodeId() };
        }
        NodeContext[] nodes = new NodeContext[nodeIds.length];
        for (int i = 0; i < nodeIds.length; i++) {
            nodes[i] = new NodeContext(nodeIds[i]);
        }
        context.addNodes(nodes);
        context.getFlow().triggerEvent(FlowEventTypes.INIT_END, context);
    }

    public void addFlow(Flow flow) {
        flowList.add(flow);
        flowMap.put(flow.getId(), flow);
    }

    private FlowResult wrapResult(FlowContext context) {
        FlowResult result = context.getResult();
        return result;

    }

    public List<Flow> getFlowList() {
        return flowList;
    }

    public void setFlowList(List<Flow> flowList) {
        this.flowList = flowList;
    }

    public String getFlowPath() {
        return flowPath;
    }

    public void setFlowPath(String flowPath) {
        this.flowPath = flowPath;
    }

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        if (event.getApplicationContext().getParent() == null) {
            FsmSpelHelper.setApplicationContext(event.getApplicationContext());
            this.applicationContext = event.getApplicationContext();
            init();
        }

    }

}

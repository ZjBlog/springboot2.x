package com.jd.jdd.yfk.fsm.model;

import com.jd.jdd.yfk.fsm.FsmContext;

public interface TransitionPostHandler {

	//	获取下一个状态节点
	public String postHandle(TransitionContext transitionContext, FsmContext context);

}
